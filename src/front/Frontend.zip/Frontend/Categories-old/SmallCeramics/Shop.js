import React, { useEffect, useState } from 'react';
import Navbar from '../Navbar/Navbar';
import Footer from '../Footer/Footer';
import { getPosts } from './APIData.js';
import InnerBanner from '../InnerBanner/InnerBanner';
import cat1 from '../../../assets/images/category/cat-1.png';
import cat2 from '../../../assets/images/category/cat-2.png';
import cat3 from '../../../assets/images/category/cat-3.png';
import cat4 from '../../../assets/images/category/cat-4.png';
import cat5 from '../../../assets/images/category/cat-5.png';

const Shop = () => {

  const [data, setData] = useState([]);

  useEffect(() => {
    getPosts().then((posts) => {
      console.log('API Response:', posts);

      if (Array.isArray(posts.products)) {
        setData(posts.products);
      } else {
        console.error('Unexpected API format', posts);
        setData([]);
      }
    });
  }, []);


  return (
    <div className="main-Shoppage">
      <Navbar />
      <InnerBanner />
      <div class="product-conatiner">
        <div class="row product_row">
          <div class="col-md-12 product-section">
            {data.length > 0 ? data.map((item) => (

              <div class="product-define">
                <div class="main-image-container">
                <img src={item.main_image}></img></div>
                <h3>{item.name}</h3>
                <p class="price">${item.price}</p>
                <button><i class="fa fa-shopping-cart"></i> Add To Cart</button>
              </div>



            )) : <p></p>}




          </div>
        </div>
        <Footer />
      </div>
    </div>
  );
};

export default Shop;
