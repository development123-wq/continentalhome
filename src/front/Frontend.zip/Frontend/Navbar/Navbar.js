import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import '../../../assets/css/Navbar.css';
import logo from '../../../assets/images/logo.png';
import cart from '../../../assets/images/cart.png';
import account from '../../../assets/images/account.png';
import wishlist from '../../../assets/images/wishlist.png';
import Image from "next/image";

const Navbar = () => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [hoveredCategoryId, setHoveredCategoryId] = useState(null);
  const [hoveredSubcategoryId, setHoveredSubcategoryId] = useState(null);
  const [cartCount, setCartCount] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [isSearching, setIsSearching] = useState(false);

  const searchRef = useRef(null);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setShowSearchDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const staticCategories = [
    { id: 1, name: 'NEW ARRIVALS', slug: 'new-arrivals' },
    {
      id: 2,
      name: 'LIGHTING',
      slug: 'lighting',
      subcategories: [
        { id: 21, name: 'Table Lamps', slug: 'table-lamps', hasNested: true },
        { id: 22, name: 'Floor Lamps', slug: 'floor-lamps', hasNested: false },
        { id: 23, name: 'Lamp Collections', slug: 'lamp-collections', hasNested: true }
      ],
      nestedItems: {
        21: [
          { name: 'Ceramic Lamps', slug: 'ceramic-lamps' },
          { name: 'Driftwood Lamps', slug: 'driftwood-lamps' },
          { name: 'Natural Vine Lamps', slug: 'natural-vine-lamps' },
          { name: 'Rope Lamps', slug: 'rope-lamps' },
          { name: 'Teak Lamps', slug: 'teak-lamps' },
          { name: 'Capiz Lamps', slug: 'capiz-lamps' }
        ],
        23: [
          { name: 'Havana Collection', slug: 'havana-lamp-collection' },
          { name: 'Rope Collection', slug: 'new-rope-lamps' },
          { name: 'Salvaged & Unique', slug: 'salvaged-unique-lamps' }
        ]
      }
    },
    {
      id: 3,
      name: 'HOME DÉCOR',
      slug: 'home-decor',
      subcategories: [
        { id: 31, name: 'Ceramic Vases', slug: 'ceramic-vases', hasNested: false },
        { id: 32, name: 'Small Ceramics', slug: 'small-ceramics', hasNested: false },
        { id: 33, name: 'Decorative Objects', slug: 'decorative-objects', hasNested: false },
        { id: 34, name: 'Sculptural Pieces', slug: 'sculptural-pieces', hasNested: false }
      ]
    },
    {
      id: 4,
      name: 'SHOP BY MATERIAL',
      slug: 'shop',
      subcategories: [
        { id: 41, name: 'Ceramic', slug: 'ceramic', hasNested: false },
        { id: 42, name: 'Driftwood', slug: 'driftwood', hasNested: false },
        { id: 43, name: 'Teak', slug: 'teak', hasNested: false },
        { id: 44, name: 'Capiz', slug: 'capiz', hasNested: false },
        { id: 45, name: 'Rope', slug: 'rope', hasNested: false },
        { id: 46, name: 'Natural Vine', slug: 'natural-vine', hasNested: false }
      ]
    }
  ];

  const getNestedItems = (categoryId, subId) => {
    const category = staticCategories.find((cat) => cat.id === categoryId);
    return category?.nestedItems?.[subId] || [];
  };

  useEffect(() => {
    const count = sessionStorage.getItem('cartItemCount');
    setCartCount(Number(count) || 0);
  }, []);

  useEffect(() => {
    const trimmedQuery = searchQuery.trim();

    if (trimmedQuery.length < 2) {
      setSearchResults([]);
      setShowSearchDropdown(false);
      setIsSearching(false);
      return;
    }

    const delayDebounce = setTimeout(async () => {
      try {
        setIsSearching(true);

        const res = await axios.get('http://187.124.157.146:5001/api/products', {
          params: {
            search: trimmedQuery,
            page: 1,
            limit: 500
          }
        });

        const products = res?.data?.products || res?.data?.data || [];

        if (Array.isArray(products)) {
          setSearchResults(products);
        } else {
          setSearchResults([]);
        }

        setShowSearchDropdown(true);
      } catch (err) {
        console.error('Search error:', err);
        setSearchResults([]);
        setShowSearchDropdown(true);
      } finally {
        setIsSearching(false);
      }
    }, 400);

    return () => clearTimeout(delayDebounce);
  }, [searchQuery]);

  const handleCatToggle = (e, id) => {
    if (isMobile) {
      e.stopPropagation();
      setHoveredCategoryId(hoveredCategoryId === id ? null : id);
      setHoveredSubcategoryId(null);
    }
  };

  const handleSubToggle = (e, id) => {
    if (isMobile) {
      e.stopPropagation();
      setHoveredSubcategoryId(hoveredSubcategoryId === id ? null : id);
    }
  };

  return (
    <div className="container" style={{ maxWidth: '100%' }}>
      <div className="row">
        <header>
          <nav className="navbar" style={{ padding: '10px' }}>
            <div className="logo cutom-logo-mobile">
              <a href="/">
                <Image src={logo} alt="Logo" style={{ width: '230px', padding: '10px 0px' }} />
              </a>
            </div>

            <div className="hamburger" onClick={() => setMenuOpen(!menuOpen)}>
              <div className="bar"></div>
              <div className="bar"></div>
              <div className="bar"></div>
            </div>

            <div
              className="search-bar"
              style={{ position: 'relative', width: '100%' }}
              ref={searchRef}
            >
              <input
                type="text"
                placeholder="Search for products..."
                className="headersearch"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => {
                  if (searchQuery.trim().length >= 2) {
                    setShowSearchDropdown(true);
                  }
                }}
              />
              <button type="button">
                <i className="fa fa-search"></i>
              </button>

              {showSearchDropdown && (
                <ul
                  style={{
                    position: 'absolute',
                    top: '100%',
                    left: 0,
                    right: 0,
                    backgroundColor: '#fff',
                    border: '1px solid #ccc',
                    zIndex: 9999,
                    maxHeight: '300px',
                    overflowY: 'auto',
                    listStyle: 'none',
                    padding: '0',
                    margin: '5px 0 0 0',
                    borderRadius: '6px',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                  }}
                >
                  {isSearching ? (
                    <li style={{ padding: '10px 12px' }}>Searching...</li>
                  ) : searchResults.length > 0 ? (
                    searchResults.map((product) => (
                      <li
                        key={product.id}
                        style={{
                          padding: '8px 12px',
                          borderBottom: '1px solid #eee'
                        }}
                      >
                        <a
                          href={`/productdetails?id=${product.id}`}
                          style={{
                            textDecoration: 'none',
                            color: '#000',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '10px'
                          }}
                          onClick={() => setShowSearchDropdown(false)}
                        >
                          <Image
                            src={`http://187.124.157.146:5001/${product.main_image}`}
                            alt={product.name}
                            style={{
                              width: '40px',
                              height: '40px',
                              objectFit: 'cover',
                              borderRadius: '6px'
                            }}
                          />
                          <div style={{ display: 'grid' }}>
                            <span>{product.name}</span>
                            <span style={{ fontSize: '12px', color: '#666' }}>
                              ${product.price}
                            </span>
                          </div>
                        </a>
                      </li>
                    ))
                  ) : (
                    <li style={{ padding: '10px 12px', color: '#666' }}>
                      No products found
                    </li>
                  )}
                </ul>
              )}
            </div>

            <div
              className="user-actions custom-header-account"
              style={{ display: 'flex', alignItems: 'center' }}
            >
              <a href="/wishlist" className="account">
                <span className="account-icon">
                  <Image src={wishlist} className="topbar-img" style={{ width: '20px' }} alt="Wishlist" />
                </span>
                <span className="account-text">Wishlist</span>
              </a>

              <a href="/sign-in" className="account">
                <span className="account-icon">
                  <Image src={cart} className="topbar-img" style={{ width: '20px' }} alt="Account" />
                </span>
                <span className="account-text">Account</span>
              </a>

              <a
                href="/add-to-cart"
                className="cart"
                style={{ position: 'relative', display: 'flex', alignItems: 'center' }}
              >
                <span className="cart-icon">
                  <Image src={account} className="topbar-img" style={{ width: '20px' }} alt="Cart" />
                </span>

                {cartCount > 0 && (
                  <span
                    style={{
                      position: 'absolute',
                      top: '-5px',
                      right: '-10px',
                      backgroundColor: 'red',
                      color: 'white',
                      borderRadius: '50%',
                      minWidth: '20px',
                      height: '20px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '12px',
                      fontWeight: 'bold',
                      padding: '0 6px',
                      boxShadow: '0 0 4px rgba(0,0,0,0.2)'
                    }}
                  >
                    {cartCount}
                  </span>
                )}

                <span className="cart-text" style={{ marginLeft: '8px', fontSize: '18px' }}>
                  Cart
                </span>
              </a>
            </div>
          </nav>
        </header>
      </div>

      <div className="row nav-bottom">
        <div
          className="col-md-12 bottom_header_row"
          style={{ display: 'flex', margin: 'auto', width: '100%', maxWidth: '1200px' }}
        >
          <div className="col-md-8" style={{ padding: '7px', margin: 'auto' }}>
            <ul className={`nav-links ${menuOpen ? 'active' : ''}`} style={{ marginBottom: '0px' }}>
              <li>
                <a href="/" onClick={() => setMenuOpen(false)}>Home</a>
              </li>
              <li>
                <a href="/about" onClick={() => setMenuOpen(false)}>About Us</a>
              </li>
              <li>
                <a href="/shop" onClick={() => setMenuOpen(false)}>Shop</a>
              </li>

              <li
                style={{ position: 'relative' }}
                onMouseEnter={() => !isMobile && setIsDropdownOpen(true)}
                onMouseLeave={() => {
                  if (!isMobile) {
                    setIsDropdownOpen(false);
                    setHoveredCategoryId(null);
                    setHoveredSubcategoryId(null);
                  }
                }}
              >
                <div
                  style={{ display: 'flex', alignItems: 'center' }}
                  onClick={() => isMobile && setIsDropdownOpen(!isDropdownOpen)}
                >
                  <a href="#">
                    Categories <i className={`fa ${isDropdownOpen ? 'fa-angle-up' : 'fa-angle-down'}`}></i>
                  </a>
                </div>

                {isDropdownOpen && (
                  <div
                    style={{
                      position: isMobile ? 'static' : 'absolute',
                      top: '100%',
                      left: 0,
                      backgroundColor: '#fff',
                      boxShadow: isMobile ? 'none' : '0 8px 25px rgba(0,0,0,0.15)',
                      zIndex: 1000,
                      width: isMobile ? '100%' : '250px',
                      borderRadius: '8px',
                      border: '1px solid #eee',
                      padding: '8px 0',
                      maxHeight: isMobile ? '60vh' : 'unset',
                      overflowY: isMobile ? 'auto' : 'visible'
                    }}
                    className="categoriessubmenu"
                  >
                    {staticCategories.map((category) => (
                      <div
                        key={category.id}
                        style={{ position: 'relative' }}
                        onMouseEnter={() => !isMobile && setHoveredCategoryId(category.id)}
                      >
                        <div
                          className="categoriessubmenudiv"
                          style={{
                            padding: '8px 12px',
                            borderBottom: '1px solid #f5f5f5',
                            backgroundColor: hoveredCategoryId === category.id ? '#f9f9f9' : 'transparent',
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center'
                          }}
                        >
                          <a
                            href={`/${category.slug}`}
                            onClick={() => setMenuOpen(false)}
                            style={{
                              fontSize: '15px',
                              fontWeight: '600',
                              color: '#333',
                              textTransform: 'uppercase',
                              textDecoration: 'none',
                              flexGrow: 1
                            }}
                          >
                            {category.name}
                          </a>

                          {category.subcategories && (
                            <i
                              className={`fa ${hoveredCategoryId === category.id ? 'fa-angle-up' : 'fa-angle-down'}`}
                              style={{ fontSize: '14px', color: '#999', padding: '5px 10px', cursor: 'pointer' }}
                              onClick={(e) => handleCatToggle(e, category.id)}
                            ></i>
                          )}
                        </div>

                        {category.subcategories && hoveredCategoryId === category.id && (
                          <div
                            style={{
                              position: isMobile ? 'static' : 'absolute',
                              top: 0,
                              left: isMobile ? '0' : '100%',
                              backgroundColor: isMobile ? '#fdfdfd' : '#fff',
                              boxShadow: isMobile ? 'none' : '0 8px 25px rgba(0,0,0,0.15)',
                              zIndex: 1001,
                              width: isMobile ? '100%' : '250px',
                              borderRadius: '8px',
                              border: isMobile ? 'none' : '1px solid #eee',
                              padding: isMobile ? '0 0 0 15px' : '10px 0'
                            }}
                          >
                            {category.subcategories.map((sub) => (
                              <div
                                key={sub.id}
                                style={{
                                  padding: '0 12px',
                                  backgroundColor: hoveredSubcategoryId === sub.id ? '#f9f9f9' : 'transparent'
                                }}
                                onMouseEnter={() => !isMobile && setHoveredSubcategoryId(sub.id)}
                              >
                                <div
                                  className="categoriessubmenudiv2"
                                  style={{
                                    display: 'flex',
                                    justifyContent: 'space-between',
                                    alignItems: 'center',
                                    padding: '8px 0'
                                  }}
                                >
                                  <a
                                    href={`/${sub.slug}`}
                                    onClick={() => setMenuOpen(false)}
                                    style={{
                                      color: '#000',
                                      fontSize: '14px',
                                      fontWeight: '500',
                                      textDecoration: 'none',
                                      flexGrow: 1
                                    }}
                                  >
                                    {sub.name}
                                  </a>

                                  {sub.hasNested && (
                                    <i
                                      className={`fa ${hoveredSubcategoryId === sub.id ? 'fa-angle-down' : 'fa-angle-right'}`}
                                      style={{ color: '#999', padding: '5px 10px', cursor: 'pointer' }}
                                      onClick={(e) => handleSubToggle(e, sub.id)}
                                    ></i>
                                  )}
                                </div>

                                {hoveredSubcategoryId === sub.id &&
                                  getNestedItems(category.id, sub.id).length > 0 && (
                                    <div
                                      style={{
                                        position: isMobile ? 'static' : 'absolute',
                                        top: 0,
                                        left: isMobile ? '0' : '100%',
                                        backgroundColor: '#fff',
                                        width: isMobile ? '100%' : '240px',
                                        borderRadius: '8px',
                                        border: isMobile ? 'none' : '1px solid #eee',
                                        padding: isMobile ? '5px 0 10px 15px' : '12px 0'
                                      }}
                                      className="subcategorysub"
                                    >
                                      {getNestedItems(category.id, sub.id).map((item) => (
                                        <div key={item.slug} style={{ padding: '5px 12px' }}>
                                          <a
                                            href={`/${item.slug}`}
                                            onClick={() => {
                                              setMenuOpen(false);
                                              setIsDropdownOpen(false);
                                            }}
                                            style={{
                                              color: '#777',
                                              textDecoration: 'none',
                                              fontSize: '13px',
                                              display: 'block'
                                            }}
                                          >
                                            {item.name}
                                          </a>
                                        </div>
                                      ))}
                                    </div>
                                  )}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </li>

              <li>
                <a href="/faqs" onClick={() => setMenuOpen(false)}>Faq</a>
              </li>
              <li>
                <a href="/contact" onClick={() => setMenuOpen(false)}>Contact</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Navbar;