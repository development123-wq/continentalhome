import React from 'react'
import '../../../assets/css/category.css'
import cat1 from '../../../assets/images/category/tablelampcategory.png' 
import cat2 from '../../../assets/images/category/driftwood.png'
import cat3 from '../../../assets/images/category/cat-3.png'
import cat4 from '../../../assets/images/category/cat-4.png'
import cat5 from '../../../assets/images/category/teaklampcategory.png'
import Image from "next/image";


const CategoryList=()=>{
    return(

        <div class="category-conatiner">
            <div class="row category_row">
                <div class="col-md-12">
                    <h2>Shop By <span class="fancytext">Category</span></h2>
                </div>
                <div class="col-md-12 category-section" style={{gap:'40px'}}>
                    <a href="/productdetails?id=1331&cat=14"><div class="category-define" style={{width:'100%'}}><Image src={cat2}></Image><h4>Driftwood Lamps</h4></div></a>
                    <a href="/productdetails?id=1330"><div class="category-define" style={{width:'100%'}}><Image src={cat1}></Image><h4>Table Lamps</h4></div></a>                  
                    <a href="https://www.faire.com/brand-portal/my-shop/products/p_7yxk8kpb3a?page=1&productType=ALL&query=v248&showCatalogUpdateTooltip=false&showCatalogUploadSuccessModal=false&sortBy=A_TO_Z"><div class="category-define" style={{width:'100%'}}><Image src={cat3}></Image><h4>Ceramic Lamps</h4></div></a>
                    <a href="/productdetails?id=1178&cat=51"><div class="category-define" style={{width:'100%'}}><Image src={cat4}></Image><h4>Floor Lamps</h4></div></a>
                    <a href="/productdetails?id=1355&cat=13 "><div class="category-define" style={{width:'100%'}}><Image src={cat5}></Image><h4>Teak Lamps</h4></div></a>
                </div>
            </div>


            {/* <div class="banner-home category-bg">
        <div class="category-banner-text">
           
            <h1 class="category-heading">Get <span class="fancy-text">10% OFF</span><br/>on your First Order</h1>
        
            <button class="banner-btn-one-1" onClick={()=>window.location.href='/shop'}>View All Products</button>
            
        
        </div>
        </div> */}




            
        </div>
        
        
        

    )
}

export default CategoryList;