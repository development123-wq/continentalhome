import React, { useEffect, useState } from 'react';
import Navbar from '../Navbar/Navbar';
import Footer from '../Footer/Footer';
import InnerBanner from '../InnerBanner/InnerBanner';
import axios from 'axios';

const Shop = () => {
  const [allProducts, setAllProducts] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [paginatedData, setPaginatedData] = useState([]);
  const [categories, setCategories] = useState([]);

  const [selectedCategory, setSelectedCategory] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [sortOrder, setSortOrder] = useState('');
  const [page, setPage] = useState(1);

  const itemsPerPage = 12;

  useEffect(() => {
    fetchAllProducts();
    fetchCategories();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [allProducts, selectedCategory, minPrice, maxPrice, sortOrder]);

  useEffect(() => {
    paginateData();
  }, [filteredData, page]);

  const fetchAllProducts = async () => {
    try {
      const res = await axios.get('http://187.124.157.146:5001/api/products?search=&page=1&limit=5000');
      if (res.data && Array.isArray(res.data.products)) {
        setAllProducts(res.data.products);
      }
    } catch (error) {
      console.error("Error fetching all products:", error);
    }
  };

  const fetchCategories = async () => {
    try {
      const res = await axios.get('http://187.124.157.146:5001/api/categories');
      setCategories(res.data.categories || []);
    } catch (err) {
      console.error("Error fetching categories:", err);
    }
  };

  const applyFilters = () => {
    let temp = [...allProducts];

    if (selectedCategory) {
      temp = temp.filter(item => item.category_name === selectedCategory);
    }
    if (minPrice) {
      temp = temp.filter(item => parseFloat(item.price) >= parseFloat(minPrice));
    }
    if (maxPrice) {
      temp = temp.filter(item => parseFloat(item.price) <= parseFloat(maxPrice));
    }

    if (sortOrder === 'asc') {
      temp.sort((a, b) => a.name.localeCompare(b.name));
    } else if (sortOrder === 'desc') {
      temp.sort((a, b) => b.name.localeCompare(a.name));
    }

    setFilteredData(temp);
    setPage(1); // reset to page 1 on filter
  };

  const paginateData = () => {
    const start = (page - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    setPaginatedData(filteredData.slice(start, end));
  };

  const handleWishlistClick = async (productId, e, itemName) => {
    e.preventDefault();

    const payload = {
      guestId: 'abc-1234',
      productId: Number(productId),
      quantity: '1',
    };

    try {
      const res = await axios.post(
        'http://187.124.157.146:5001/api/wishlists/add',
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );

      console.log('Wishlist Response:', res.data);
      alert(`Product "${itemName}" has been added successfully!`);
    } catch (err) {
      console.error('API Error:', err?.response?.data || err.message);
      alert('Failed to add product to wishlist.');
    }
  };

  return (
    <div className="main-Shoppage">
      <Navbar />
      <InnerBanner />
      <div className="product-conatiner">
        <div className="row product_row">
          {/* Sidebar Filters */}
          <div className="col-md-3 filter-sidebar">
            <h5>Filters</h5>

            <div className="mb-4">
              <label className="form-label">Sort Alphabetically</label>
              <select
                className="form-control"
                value={sortOrder}
                onChange={(e) => setSortOrder(e.target.value)}
              >
                <option value="">-- Select --</option>
                <option value="asc">A - Z</option>
                <option value="desc">Z - A</option>
              </select>
            </div>

            <div className="mb-4">
              <label className="form-label">Price Range</label>
              <input type="number" placeholder="Min" className="form-control mb-2" value={minPrice} onChange={(e) => setMinPrice(e.target.value)} />
              <input type="number" placeholder="Max" className="form-control" value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} />
            </div>

           
          </div>

          {/* Products Section */}
          <div className="col-md-9 product-section">
            <div className="row">
              {paginatedData.length > 0 ? paginatedData.map((item) => (
                <div className="col-md-4 mb-4" key={item.id}>
                  <a
                    href={`/productdetails?id=${item.id}&cat=${item.category_ids}`}
                    style={{ position: 'relative', display: 'block' }}
                  >
                    <div className="product-define" style={{ width: '100%' }}>
                      <div className="main-image-container" style={{ position: 'relative' }}>
                        <img src={`http://187.124.157.146:5001/${item.main_image}`} alt={item.name} />
                        <i
                          className="fa fa-heart wishlist-icon"
                          onClick={(e) => handleWishlistClick(item.id, e, item.name)}
                          title="Add to Wishlist"
                        ></i>
                      </div>
                      <h3 style={{ paddingRight: '20px', paddingLeft: '20px', height: '50px' }}>{item.name}</h3>
                      <p className="price">${item.price}</p>
                      <button>Buy Now</button>
                    </div>
                  </a>
                </div>
              )) : <p style={{ padding: "20px" }}>No products found.</p>}
            </div>
          </div>
        </div>

        {/* Pagination Buttons */}
        <div style={{ textAlign: 'center', margin: '20px' }}>
          <button className="prev-btn" onClick={() => setPage(prev => Math.max(prev - 1, 1))} disabled={page === 1}>
            Previous
          </button>
          <span style={{ margin: '0 15px' }}>Page {page}</span>
          <button
            className="next-btn"
            onClick={() => setPage(prev => prev + 1)}
            disabled={page * itemsPerPage >= filteredData.length}
          >
            Next
          </button>
        </div>

        <Footer />
      </div>

      {/* Wishlist Icon CSS */}
      <style>{`
        .wishlist-icon {
          position: absolute;
          top: 10px;
          right: 10px;
          font-size: 24px;
          color: black;
          border: 2px solid black;
          border-radius: 50%;
          padding: 4px;
          cursor: pointer;
          transition: color 0.3s ease, border-color 0.3s ease;
          z-index: 10;
          user-select: none;
        }
        .wishlist-icon:hover {
          color: red;
          border-color: red;
        }
      `}</style>
    </div>
  );
};

export default Shop;
