import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';

const SupportDetails = () => {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const customerId = searchParams.get('id');

  const [messages, setMessages] = useState([]);
  const [user, setUser] = useState(null);
  const [adminMessage, setAdminMessage] = useState('');
  const [sending, setSending] = useState(false);

  const token = sessionStorage.getItem('authToken'); // ✅ Token fetched here

  useEffect(() => {
    if (customerId) {
      fetchMessages();
    }
  }, [customerId]);

  const fetchMessages = async () => {
    try {
      const res = await axios.get(
        `http://187.124.157.146:5001/api/supports/messages?isAdmin=1&customerId=${customerId}&page=1&limit=3000`,
        {
          headers: {
            Authorization: `Bearer ${token}`, // ✅ Token passed in headers
          },
        }
      );

      const fetchedMessages = res.data?.messages || [];
      setMessages(fetchedMessages);

      if (fetchedMessages.length > 0) {
        const firstMsg = fetchedMessages[0];
        setUser({
          name: firstMsg.first_name || 'N/A',
          email: firstMsg.email || '',
          phone: firstMsg.phone || '',
        });
      }
    } catch (err) {
      console.error('Failed to fetch messages:', err.response?.data || err.message);
    }
  };

  const handleSendMessage = async () => {
    if (!adminMessage.trim()) return;

    setSending(true);
    try {
      await axios.post(
        'http://187.124.157.146:5001/api/supports/admin/send',
        {
          customerId: Number(customerId),
          message: adminMessage,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`, // ✅ Token passed here too
          },
        }
      );

      setAdminMessage('');
      fetchMessages(); // reload messages after sending
    } catch (err) {
      console.error('Message sending failed:', err.response?.data || err.message);
    } finally {
      setSending(false);
    }
  };

  return (
    <div style={{ padding: '30px', fontFamily: 'Segoe UI, sans-serif' }}>
      <h2>Support Details - Customer #{customerId}</h2>

      {user ? (
        <>
          <p><strong>Name:</strong> {user.name}</p>
          <p><strong>Email:</strong> {user.email}</p>
          <p><strong>Phone:</strong> {user.phone}</p>
        </>
      ) : (
        <p>Loading user info...</p>
      )}

      <hr />

      <h3>Conversation:</h3>
      <div style={{ marginTop: '20px' }}>
        {messages.length > 0 ? (
          messages.map((msg) => (
            <div
              key={msg.id}
              style={{
                marginBottom: '10px',
                backgroundColor: msg.sender_type === 'admin' ? '#e0ffe0' : '#f0f0f0',
                padding: '10px',
                borderRadius: '5px',
              }}
            >
              <p><strong>{msg.sender_type === 'admin' ? 'Admin' : 'Customer'}:</strong></p>
              <p>{msg.message}</p>
              <p style={{ fontSize: '12px', color: 'gray' }}>
                {new Date(msg.created_at).toLocaleString()}
              </p>
            </div>
          ))
        ) : (
          <p>No messages found.</p>
        )}
      </div>

      <hr />

      <h4>Reply to Customer:</h4>
      <div style={{ marginTop: '10px' }}>
        <textarea
          rows={4}
          placeholder="Type your message here..."
          value={adminMessage}
          onChange={(e) => setAdminMessage(e.target.value)}
          style={{ width: '100%', padding: '10px', borderRadius: '5px' }}
        />
        <button
          onClick={handleSendMessage}
          disabled={sending}
          style={{
            marginTop: '10px',
            padding: '10px 20px',
            color: '#fff',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
          }}
          className="btn btn-primary"
        >
          {sending ? 'Sending...' : 'Send Message'}
        </button>
      </div>
    </div>
  );
};

export default SupportDetails;
