import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Support = () => {
  const navigate = useNavigate();
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    fetchSupportMessages();
  }, []);

  const fetchSupportMessages = async () => {
    try {
      const res = await axios.get(
        'http://187.124.157.146:5001/api/supports/messages?isAdmin=1&page=1&limit=3000'
      );

      const messages = res.data?.messages || [];

      // Unique customers by customer_id
      const customerMap = new Map();

      messages.forEach((msg) => {
        if (!customerMap.has(msg.customer_id)) {
          customerMap.set(msg.customer_id, {
            id: msg.customer_id,
            name: msg.first_name,
            email: msg.email,
            phone: msg.phone,
            createdAt: msg.created_at,
          });
        }
      });

      const finalList = Array.from(customerMap.values());
      setCustomers(finalList);
      setError(false);
    } catch (err) {
      console.error('❌ Error fetching data:', err);
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '30px', fontFamily: 'Segoe UI, sans-serif', backgroundColor: '#fff' }}>
      <h2 style={{ fontSize: '24px', marginBottom: '5px' }}>Support</h2>
      <p style={{ marginBottom: '20px', color: '#555' }}>Your Support with support.</p>

      {loading ? (
        <p>Loading support messages...</p>
      ) : error ? (
        <p style={{ color: 'red' }}>❌ Error loading data. Try again later.</p>
      ) : customers.length === 0 ? (
        <p>No support messages found.</p>
      ) : (
        <>
          <input
            type="text"
            placeholder="Search by name, email, or phone"
            style={{
              width: '100%',
              padding: '12px 16px',
              border: '1px solid #ccc',
              borderRadius: '10px',
              fontSize: '16px',
              marginBottom: '20px',
              boxSizing: 'border-box',
            }}
          />

          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '16px' }}>
            <thead>
              <tr style={{ textAlign: 'left', borderBottom: '2px solid #ccc' }}>
                <th style={{ padding: '14px 10px' }}>ID</th>
                <th style={{ padding: '14px 10px' }}>Name</th>
                <th style={{ padding: '14px 10px' }}>Email</th>
                <th style={{ padding: '14px 10px' }}>Phone</th>
                <th style={{ padding: '14px 10px' }}>Register Date</th>
              </tr>
            </thead>
            <tbody>
              {customers.map((user, index) => (
                <tr
                  key={user.id}
                  style={{ borderBottom: '1px solid #eee', cursor: 'pointer' }}
                  onClick={() =>
                    navigate(`/support-details?id=${user.id}`, { state: user })
                  }
                >
                  <td style={{ padding: '14px 10px' }}>#{index + 1}</td>
                  <td style={{ padding: '14px 10px' }}>{user.name}</td>
                  <td style={{ padding: '14px 10px' }}>{user.email}</td>
                  <td style={{ padding: '14px 10px' }}>{user.phone}</td>
                  <td style={{ padding: '14px 10px' }}>
                    {user.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'N/A'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}
    </div>
  );
};

export default Support;
