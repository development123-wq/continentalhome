import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import DataTable from 'react-data-table-component';
import PageHeader1 from '../../components/common/PageHeader1';

function OrderList() {
  const [orders, setOrders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const navigate = useNavigate();

  useEffect(() => {
    setLoading(true);
    fetch('http://187.124.157.146:5001/api/orders?page=1&limit=5000')
      .then(res => {
        if (!res.ok) throw new Error('Failed to fetch data');
        return res.json();
      })
      .then(data => {
        const reversed = Array.isArray(data.orders) ? [...data.orders].reverse() : [];
        setOrders(reversed);
        setFilteredOrders(reversed);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  useEffect(() => {
    const filtered = orders.filter(o =>
      o.shipping_first_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.id?.toString().includes(searchTerm)
    );
    setFilteredOrders(filtered);
  }, [searchTerm, orders]);

  const handleRowsPerPageChange = (newPerPage, page) => {
    setRowsPerPage(newPerPage);
  };

  const columns = [
    { name: 'Order ID', selector: row => `#${row.id}`, sortable: true },
    { name: 'Customer Name', selector: row => row.shipping_first_name || 'N/A', sortable: true },
    { name: 'Payment', selector: () => 'Online', sortable: true },
    { name: 'Total', selector: row => `$${row.order_total_inc_tax}`, sortable: true },
  ];

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div className="body d-flex py-3">
      <div className="container-xxl">
        <PageHeader1 pagetitle="Orders List" />
        <div className="row g-3 mb-3">
          <div className="col-md-12">
            <div className="card"><div className="card-body">
              <input
                type="text"
                className="form-control mb-3"
                placeholder="Search by customer name or order ID"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
              <DataTable
                columns={columns}
                data={filteredOrders}
                pagination
                paginationPerPage={rowsPerPage}
                paginationRowsPerPageOptions={[10, 30, 50, 100, 250, 500, filteredOrders.length]}
                onChangeRowsPerPage={handleRowsPerPageChange}
                highlightOnHover
                pointerOnHover
                onRowClicked={row => navigate(`/order-detail?id=${row.id}`)}
                className="table table-hover align-middle mb-0 nowrap"
              />
            </div></div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default OrderList;
