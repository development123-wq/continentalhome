import React, { useState, useEffect } from 'react'; 
import { useNavigate } from 'react-router-dom'; 
import DataTable from 'react-data-table-component';
import PageHeader1 from '../../components/common/PageHeader1';

function OrderList() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [page, setPage] = useState(1);
  const [totalRows, setTotalRows] = useState(0);

  const navigate = useNavigate();

  useEffect(() => {
    setLoading(true);
    fetch(`http://187.124.157.146:5001/api/orders?page=${page}&limit=${rowsPerPage}`)
      .then((response) => {
        if (!response.ok) throw new Error('Failed to fetch data');
        return response.json();
      })
      .then((data) => {
        if (data && Array.isArray(data.orders)) {
          setOrders(data.orders);
          setTotalRows(data.total || 0);
        } else {
          setError('Invalid data format');
        }
        setLoading(false);
      })
      .catch((error) => {
        setError(error.message);
        setLoading(false);
      });
  }, [page, rowsPerPage]);

  const handleRowClick = (row) => {
    navigate(`/order-detail?id=${row.id}`);
  };

  const handlePageChange = (newPage) => setPage(newPage);
  const handleRowsPerPageChange = (newRowsPerPage) => {
    setRowsPerPage(newRowsPerPage);
    setPage(1);
  };

  const columns = [
    { name: 'Order ID', selector: row => `#${row.id}`, sortable: true },
    
    { name: 'Customer Name', selector: row => row.shipping_first_name, sortable: true },
    { name: 'Payment', selector: row => "Online", sortable: true },
    { name: 'Total', selector: row => `$${row.order_total_inc_tax}`, sortable: true },
  ];

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div className="body d-flex py-3">
      <div className="container-xxl">
        <PageHeader1 pagetitle="Orders List" />
        <div className="row g-3 mb-3">
          <div className="col-md-12">
            <div className="card">
              <div className="card-body">
                <DataTable
                  columns={columns}
                  data={orders}
                  pagination
                  paginationServer
                  paginationTotalRows={totalRows}
                  paginationPerPage={rowsPerPage}
                  paginationRowsPerPageOptions={[10, 30, 50, 100, 250, 500]} // ✅ Custom options here
                  onChangePage={handlePageChange}
                  onChangeRowsPerPage={handleRowsPerPageChange}
                  highlightOnHover
                  pointerOnHover
                  onRowClicked={handleRowClick}
                  className="table myDataTable table-hover align-middle mb-0 d-row nowrap dataTable no-footer dtr-inline"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default OrderList;
