import React, { useEffect, useState } from 'react';
import PageHeader1 from '../../components/common/PageHeader1';
import AddressBlock from '../../components/Orders/OrdersDetail/AddressBlock';
import CardBlock from '../../components/Orders/OrdersDetail/CardBlock';
import OrderSummeryBlock from '../../components/Orders/OrdersDetail/OrderSummeryBlock';
import StatusOrderBlock from '../../components/Orders/OrdersDetail/StatusOrderBlock';
import DownloadModal from '../../components/Orders/OrdersDetail/DownloadModal'; 
import { useLocation } from 'react-router-dom';

function OrderDetail() {
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false); 

  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const customerId = queryParams.get('id');

  useEffect(() => {
    const fetchOrderData = async () => {
      try {
        const response = await fetch(`http://187.124.157.146:5001/api/orders/${customerId}`);
        if (!response.ok) throw new Error('Failed to fetch order data');
        const data = await response.json();
        setOrder(data.order);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchOrderData();
  }, [customerId]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;
  if (!order) return <div>No order data available</div>;

  // ---------- Helpers & derived values ----------
  const num = (v) => (v === null || v === undefined || v === '' ? 0 : Number.parseFloat(v) || 0);
  const money = (v) => `$${num(v).toFixed(2)}`;

  const subtotalInc = num(order.subtotal_inc_tax);                 // e.g. 75.00
  const shippingInc = num(order.shipping_cost_inc_tax);            // e.g. 0.00
  const couponCode = order.coupon_details || '-';                  // e.g. Summer29

  // Compute coupon value safely:
  // Prefer sub_total_inc_coupon if present, else coupon_discount_value field
  const subAfterCoupon = order.sub_total_inc_coupon !== undefined
    ? num(order.sub_total_inc_coupon)
    : Math.max(0, subtotalInc - num(order.coupon_discount_value));

  const couponValue = order.sub_total_inc_coupon !== undefined
    ? Math.max(0, subtotalInc - subAfterCoupon)
    : num(order.coupon_discount_value);

  const orderTotalIncTax = num(order.order_total_inc_tax);         // e.g. 55.00

  return (
    <div className="body d-flex py-3">
      <div className="container-xxl">
        <PageHeader1 pagetitle={`Order Details: #Order-${order.id}`} Orderdetail={false} />
        <CardBlock order={order} />

        {/* Download Modal */}
        <DownloadModal show={showModal} onClose={() => setShowModal(false)} order={order} />

        <div className="row g-3 mb-3 row-cols-1 row-cols-md-1 row-cols-lg-3 row-cols-xl-3 row-cols-xxl-3 row-deck">
          <AddressBlock order={order} />

          {/* Invoice Detail card */}
          <div className="col">
            <div className="card">
              <div className="card-header py-3 d-flex justify-content-between bg-transparent border-bottom-0">
                <h6 className="mb-0 fw-bold">Invoice Detail</h6>
                <a href="#!" className="text-muted" onClick={() => setShowModal(true)}>Download</a>
              </div>
              <div className="card-body">
                <div className="row g-3">
                  <div className="col-12">
                    <label className="form-label col-6 col-sm-5">Number:</label>
                    <span><strong>#{order.id}</strong></span>
                  </div>
                  <div className="col-12">
                    <label className="form-label col-6 col-sm-5">Seller GST:</label>
                    <span><strong>{order.billing_gst}</strong></span>
                  </div>
                  <div className="col-12">
                    <label className="form-label col-6 col-sm-5">Purchase GST:</label>
                    <span><strong>{order.shipping_gst}</strong></span>
                  </div>

                  {/* NEW: Coupon & Total inside Invoice */}
                  <div className="col-12">
                    <label className="form-label col-6 col-sm-5">Coupon Code:</label>
                    <span><strong>{couponCode}</strong></span>
                  </div>
                  <div className="col-12">
                    <label className="form-label col-6 col-sm-5">Coupon Value:</label>
                    <span><strong>{money(couponValue)}</strong></span>
                  </div>
                  <div className="col-12">
                    <label className="form-label col-6 col-sm-5">Order Total (Inc Tax):</label>
                    <span><strong>{money(orderTotalIncTax)}</strong></span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* /Invoice Detail card */}
        </div>

        <div className="row g-3 mb-3">
          <div className="col-xl-12 col-xxl-8">
            <div className="card">
              <div className="card-header py-3 d-flex justify-content-between bg-transparent border-bottom-0">
                <h6 className="mb-0 fw-bold">Order Summary</h6>
              </div>
              <div className="card-body">
                <div className="product-cart">
                  <div className="checkout-table table-responsive">
                    <div id="myCartTable_wrapper" className="dataTables_wrapper dt-bootstrap5 no-footer">
                      <div className="row">
                        <OrderSummeryBlock products={order.products} />
                      </div>
                    </div>
                  </div>

                  <div className="checkout-coupon-total checkout-coupon-total-2 d-flex flex-wrap justify-content-end">
                    <div className="checkout-total">
                      <div className="single-total">
                        <p className="value">Subtotal Price:</p>
                        <p className="price">{money(subtotalInc)}</p>
                      </div>

                      {/* NEW: Coupon in totals */}
                      <div className="single-total">
                        <p className="value">Coupon Code:</p>
                        <p className="price">{couponCode}</p>
                      </div>
                      <div className="single-total">
                        <p className="value">Coupon Value (-):</p>
                        <p className="price">{money(couponValue)}</p>
                      </div>

                      {/* Optional: show subtotal after coupon if API provided */}
                      {order.sub_total_inc_coupon !== undefined && (
                        <div className="single-total">
                          <p className="value">Subtotal After Coupon:</p>
                          <p className="price">{money(subAfterCoupon)}</p>
                        </div>
                      )}

                      <div className="single-total">
                        <p className="value">Shipping Cost (+):</p>
                        <p className="price">{money(shippingInc)}</p>
                      </div>

                      {/* If you want tax separately, map order.tax_total */}
                      {/* <div className="single-total">
                        <p className="value">Tax:</p>
                        <p className="price">{money(order.tax_total)}</p>
                      </div> */}

                      <div className="single-total total-payable">
                        <p className="value">Total Payable (Inc Tax):</p>
                        <p className="price">{money(orderTotalIncTax)}</p>
                      </div>
                    </div>
                  </div>
                  {/* /totals */}
                </div>
              </div>
            </div>
          </div>

          <div className="col-xl-12 col-xxl-4">
            <StatusOrderBlock order={order} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default OrderDetail;
