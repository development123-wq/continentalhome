import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import PageHeader1 from '../../components/common/PageHeader1';

function CategoriesList() {
  const [subcategories, setSubcategories] = useState([]);
  const [filteredSubcategories, setFilteredSubcategories] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => {
    fetch("http://187.124.157.146:5001/api/subcategories?search=&page=1&limit=50")
      .then(response => response.json())
      .then(data => {
        if (data?.subcategories) {
          setSubcategories(data.subcategories);
          setFilteredSubcategories(data.subcategories);
        } else {
          console.warn("No 'subcategories' field in response");
        }
      })
      .catch(error => console.error("Error fetching subcategories:", error));
  }, []);

  useEffect(() => {
    const filtered = subcategories.filter(sub =>
      sub.name?.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredSubcategories(filtered);
    setCurrentPage(1); // Reset to first page on search
  }, [searchTerm, subcategories]);

  const handleDelete = async (id) => {
    const confirmed = window.confirm("Are you sure you want to delete this subcategory?");
    if (!confirmed) return;

    const token = sessionStorage.getItem('authToken');

    try {
      const response = await fetch(`http://187.124.157.146:5001/api/subcategories/delete/${id}`, {
        method: "DELETE",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (response.ok) {
        alert("Subcategory deleted successfully!");
        const updated = subcategories.filter(sub => sub.id !== id);
        setSubcategories(updated);
        setFilteredSubcategories(updated);
      } else {
        const data = await response.json();
        alert(`Failed to delete: ${data.message || "Unknown error"}`);
      }
    } catch (error) {
      console.error("Error deleting subcategory:", error);
      alert("Something went wrong!");
    }
  };

  // Pagination logic
  const totalPages = Math.ceil(filteredSubcategories.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentItems = filteredSubcategories.slice(startIndex, startIndex + itemsPerPage);

  const changePage = (page) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  return (
    <div className="body d-flex py-3">
      <div className="container-xxl">
        <PageHeader1 pagetitle='SubCategorie List' righttitle='Add Subcategory' link='/subcategories-add' routebutton={true} />
        <div className="row g-3 mb-3">
          <div className="col-md-12">
            <div className="card">
              <div className="card-body">

                {/* 🔍 Search Input */}
                <div className="mb-3">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search by subcategory name"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>

                {/* 🧾 Subcategory Table */}
                <div className='table-responsive'>
                  <table className="table table-hover align-middle mb-0 nowrap">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Subcategory</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {currentItems.length > 0 ? (
                        currentItems.map((sub, index) => (
                          <tr key={sub._id || index}>
                            <td>{startIndex + index + 1}</td>
                            <td>{sub.name}</td>
                            <td>
                              <span className="badge bg-success">
                                {sub.status || "Published"}
                              </span>
                            </td>
                            <td>
                              <div className="btn-group" role="group">
                                <Link to={`/subcategories-edit?id=${sub.id}`} className="btn btn-outline-secondary">
                                  <i className="icofont-edit text-success"></i>
                                </Link>
                                <button onClick={() => handleDelete(sub.id)} className="btn btn-outline-secondary deleterow">
                                  <i className="icofont-ui-delete text-danger"></i>
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan="4" className="text-center">No data available</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

                {/* ➡️ Pagination Controls */}
                <div className="d-flex justify-content-center align-items-center gap-3 mt-4">
                  <button
                    className="btn btn-outline-secondary"
                    onClick={() => changePage(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    &lt;
                  </button>

                  <span style={{ fontWeight: 500 }}>
                    Page <strong>{currentPage}</strong> of <strong>{totalPages}</strong>
                  </span>

                  <button
                    className="btn btn-outline-secondary"
                    onClick={() => changePage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    &gt;
                  </button>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CategoriesList;
