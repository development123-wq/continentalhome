import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import PageHeader1 from '../../components/common/PageHeader1';

function CategoriesList() {
  const [categories, setCategories] = useState([]);
  const [filteredCategories, setFilteredCategories] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => {
    fetch("http://187.124.157.146:5001/api/categories?page=1&limit=500")
      .then(response => response.json())
      .then(data => {
        if (data?.categories) {
          setCategories(data.categories);
          setFilteredCategories(data.categories);
        } else {
          console.warn("No 'categories' field in response");
        }
      })
      .catch(error => console.error("Error fetching categories:", error));
  }, []);

  useEffect(() => {
    const filtered = categories.filter(cat =>
      cat.name?.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredCategories(filtered);
    setCurrentPage(1); // Reset to first page when search changes
  }, [searchTerm, categories]);

  const handleDelete = async (id) => {
    const confirmed = window.confirm("Are you sure you want to delete this category?");
    if (!confirmed) return;

    const token = sessionStorage.getItem('authToken');

    try {
      const response = await fetch(`http://187.124.157.146:5001/api/categories/delete/${id}`, {
        method: "DELETE",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (response.ok) {
        alert("Category deleted successfully!");
        const updated = categories.filter(cat => cat.id !== id);
        setCategories(updated);
        setFilteredCategories(updated);
      } else {
        const data = await response.json();
        alert(`Failed to delete: ${data.message || "Unknown error"}`);
      }
    } catch (error) {
      console.error("Error deleting category:", error);
      alert("Something went wrong!");
    }
  };

  // Pagination logic
  const totalPages = Math.ceil(filteredCategories.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentItems = filteredCategories.slice(startIndex, startIndex + itemsPerPage);

  const changePage = (page) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  return (
    <div className="body d-flex py-3">
      <div className="container-xxl">
        <PageHeader1 pagetitle='Categorie List' righttitle='Add Categories' link='/categories-add' routebutton={true} />
        <div className="row g-3 mb-3">
          <div className="col-md-12">
            <div className="card">
              <div className="card-body">

                {/* 🔍 Search Input */}
                <div className="mb-3">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search by category name"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>

                {/* 🧾 Category Table */}
                <div className='table-responsive'>
                  <table className="table table-hover align-middle mb-0 nowrap">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Category</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {currentItems.length > 0 ? (
                        currentItems.map((cat, index) => (
                          <tr key={cat._id || index}>
                            <td>{startIndex + index + 1}</td>
                            <td>{cat.name}</td>
                            <td>
                              <span className="badge bg-success">
                                {cat.status || "Published"}
                              </span>
                            </td>
                            <td>
                              <div className="btn-group" role="group">
                                <Link to={`/categories-edit?id=${cat.id}`} className="btn btn-outline-secondary">
                                  <i className="icofont-edit text-success"></i>
                                </Link>
                                <button onClick={() => handleDelete(cat.id)} className="btn btn-outline-secondary deleterow">
                                  <i className="icofont-ui-delete text-danger"></i>
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan="4" className="text-center">No data available</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

                {/* ➡️ Clean Pagination */}
                <div className="d-flex justify-content-center align-items-center gap-3 mt-4">
                  <button
                    className="btn btn-outline-secondary"
                    onClick={() => changePage(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    &lt;
                  </button>

                  <span style={{ fontWeight: 500 }}>
                    Page <strong>{currentPage}</strong> of <strong>{totalPages}</strong>
                  </span>

                  <button
                    className="btn btn-outline-secondary"
                    onClick={() => changePage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    &gt;
                  </button>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CategoriesList;
