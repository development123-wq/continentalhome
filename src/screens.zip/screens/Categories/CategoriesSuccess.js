import React from 'react';
import PageHeader1 from '../../components/common/PageHeader1';
import VisibilityStatus from '../../components/Categories/CategoriesAdd/VisibilityStatus';
import PublicaSchedule from '../../components/Categories/CategoriesAdd/PublicaSchedule';
import Categories from '../../components/Categories/CategoriesAdd/Categories';
import CategoriesImage from '../../components/Categories/CategoriesAdd/CategoriesImage';
import BasicInformation from '../../components/Categories/CategoriesAdd/BasicInformation';
import CroppedImages from '../../components/Categories/CategoriesAdd/CroppedImages';

function CategoriesSuccess() {
    return (
        <p>Done</p>
    )
}
export default CategoriesSuccess;