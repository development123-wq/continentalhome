import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Editor } from '@tinymce/tinymce-react';

function AddBlogForm() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    title: '',
    short_description: '',
    description: '',
    image: null,
    imagePreview: '',
    publish_date_time: '',
    author_name: '',
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = e => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleEditorChange = (content, field) => {
    setFormData(prev => ({ ...prev, [field]: content }));
  };

  const handleImageChange = e => {
    const file = e.target.files[0];
    if (file) {
      setFormData(prev => ({
        ...prev,
        image: file,
        imagePreview: URL.createObjectURL(file),
      }));
    }
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const token = sessionStorage.getItem('authToken');
      if (!token) {
        alert('Please login first.');
        setLoading(false);
        return;
      }

      const postData = new FormData();
      postData.append('title', formData.title);
      postData.append('short_description', formData.short_description);
      postData.append('description', formData.description);
      postData.append('publish_date_time', formData.publish_date_time);
      postData.append('author_name', formData.author_name);
      if (formData.image) {
        postData.append('image', formData.image);
      }

      await axios.post(
        'http://187.124.157.146:5001/api/blogs/add',
        postData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      alert('Blog added successfully!');
      navigate('/all-blogs');
    } catch (err) {
      console.error('Add blog error:', err.response?.data || err.message);
      setError('Failed to add blog.');
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <p>Loading...</p>;
  if (error) return <p className="text-danger">{error}</p>;

  return (
    <div className="container mt-4" style={{ maxWidth: '100%' }}>
      <h2>Add New Blog</h2>
      <form onSubmit={handleSubmit} encType="multipart/form-data">
        <div className="mb-3">
          <label className="form-label">Title</label>
          <input
            name="title"
            value={formData.title}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Short Description</label>
          <input
            name="short_description"
            value={formData.short_description}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Description</label>
          <Editor
            apiKey="ewqu5ti6bsjbxirh6rptpf3m05mwek075mt56suan91l8exv"
            value={formData.description}
            onEditorChange={(content) => handleEditorChange(content, 'description')}
            init={{
              height: 400,
              menubar: true,
              plugins: 'lists link image code table media',
              toolbar:
                'undo redo | formatselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | image media table | code',
            }}
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Publish Date</label>
          <input
            type="date"
            name="publish_date_time"
            value={formData.publish_date_time}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Author Name</label>
          <input
            name="author_name"
            value={formData.author_name}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Image</label>
          {formData.imagePreview && (
            <div className="mb-2">
              <img
                src={formData.imagePreview}
                alt="Preview"
                style={{ maxWidth: '100%', maxHeight: '200px' }}
              />
            </div>
          )}
          <input
            type="file"
            accept="image/*"
            onChange={handleImageChange}
            className="form-control"
          />
        </div>

        <button type="submit" className="btn btn-success" disabled={loading}>
          {loading ? 'Adding...' : 'Add Blog'}
        </button>
      </form>
    </div>
  );
}

export default AddBlogForm;
