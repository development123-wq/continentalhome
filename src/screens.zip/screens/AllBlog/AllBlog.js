import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function BlogBlock({ search = '', pageLimit = 10 }) {
  const [blogs, setBlogs] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  useEffect(() => {
    axios
      .get(`http://187.124.157.146:5001/api/blogs?search=${search}&page=${currentPage}&limit=${pageLimit}`)
      .then(res => {
        setBlogs(res.data.blogs || []);
        setCurrentPage(res.data.currentPage || 1);
        setTotalPages(res.data.totalPages || 1);
      })
      .catch(err => {
        console.error("Error fetching blogs:", err);
      });
  }, [search, currentPage, pageLimit]);

  const handleDelete = (id) => {
    const token = sessionStorage.getItem('authToken');

    if (!token) {
      alert("No auth token found. Please log in.");
      return;
    }

    if (window.confirm("Are you sure you want to delete this blog?")) {
      axios.delete(`http://187.124.157.146:5001/api/blogs/delete/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      })
      .then(() => {
        // Remove deleted blog from state so UI updates
        setBlogs(prev => prev.filter(blog => blog.id !== id));
        alert("Blog deleted successfully!");
      })
      .catch(err => {
        console.error("Error deleting blog:", err);
        alert("Failed to delete blog.");
      });
    }
  };

  return (
    <div className="blog-container p-3">
      <h3>Blogs</h3>
      <div className="d-flex flex-wrap gap-3">
        {blogs.length === 0 && <p>No blogs found.</p>}
        {blogs.map(blog => (
          <div
            key={blog.id}
            className="card"
            style={{
              minWidth: '300px',
              maxWidth: '320px',
              backgroundColor: 'white',
            }}
          >
            <img
              src={`http://187.124.157.146:5001/${blog.image}`}
              alt={blog.title}
              className="card-img-top"
              style={{ height: '180px', objectFit: 'cover' }}
            />
            <div className="card-body d-flex flex-column">
              <h5 className="card-title">{blog.title}</h5>
              <p className="card-text">{blog.short_description}</p>
              <small className="text-muted mb-3">
                By {blog.author_name} | {new Date(blog.publish_date_time).toLocaleDateString()}
              </small>

              <div className="d-flex justify-content-center gap-3 mt-auto">
                <Link to={`/edit-blog?id=${blog.id}`} className="btn btn-outline-secondary btn-sm">
                  <i className="icofont-edit text-success"></i> Edit
                </Link>
                <button
                  onClick={() => handleDelete(blog.id)}
                  className="btn btn-outline-secondary btn-sm"
                >
                  <i className="icofont-ui-delete text-danger"></i> Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="d-flex justify-content-center mt-4 gap-3">
        <button
          disabled={currentPage <= 1}
          onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
          className="btn btn-outline-primary"
        >
          Prev
        </button>
        <span>Page {currentPage} of {totalPages}</span>
        <button
          disabled={currentPage >= totalPages}
          onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
          className="btn btn-outline-primary"
        >
          Next
        </button>
      </div>
    </div>
  );
}

export default BlogBlock;
