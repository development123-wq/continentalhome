import React, { useEffect, useState } from 'react';
import PageHeader1 from '../../components/common/PageHeader1';
import InventoryInfo from '../../components/Products/ProductAdd/InventoryInfo';
import PricingInfo from '../../components/Products/ProductAdd/PricingInfo';
import Tags from '../../components/Products/ProductAdd/Tags';
import VisibilityStatus from '../../components/Products/ProductAdd/VisibilityStatus';
import BasicInformation from '../../components/Products/ProductAdd/BasicInformation';
import Select from 'react-select';

function ProductAdd() {
  const [selectedGalleryImages, setSelectedGalleryImages] = useState([]);
  const [previewUrls, setPreviewUrls] = useState([]);
  const [categoryOptions, setCategoryOptions] = useState([]);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [subcategoryOptions, setSubcategoryOptions] = useState([]);
  const [selectedSubcategories, setSelectedSubcategories] = useState([]);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await fetch('http://187.124.157.146:5001/api/categories?page=1&limit=20');
        const data = await response.json();
        const categories = Array.isArray(data.categories) ? data.categories : data;

        const options = categories.map((cat) => ({
          value: cat.id,
          label: cat.name,
          subcategories: cat.subcategories || [],
        }));

        setCategoryOptions(options);
      } catch (error) {
        console.error('Error fetching categories:', error);
      }
    };

    fetchCategories();
  }, []);

  useEffect(() => {
    const subs = selectedCategories.flatMap((cat) =>
      (cat.subcategories || []).map((sub) => ({
        value: sub.id,
        label: sub.name,
      }))
    );
    setSubcategoryOptions(subs);
    setSelectedSubcategories([]);
  }, [selectedCategories]);

  const handleGalleryChange = (e) => {
    const files = Array.from(e.target.files);
    setSelectedGalleryImages(files);
    const previews = files.map((file) => URL.createObjectURL(file));
    setPreviewUrls(previews);
  };

  const handleCategoryChange = (selected) => {
    setSelectedCategories(selected || []);
  };

  const handleSubcategoryChange = (selected) => {
    setSelectedSubcategories(selected || []);
  };

  const formsubmit = async (e) => {
    e.preventDefault();

    if (selectedCategories.length === 0) {
      alert('⚠️ Please select at least one category.');
      return;
    }

    const form = e.target;
    const formData = new FormData();

    // ---- helpers ----
    const safe = (v) => {
      if (v === undefined || v === null) return '';
      // Agar kisi wajah se "undefined" string aa raha ho to clean kar do
      const s = String(v);
      return s.toLowerCase().trim() === 'undefined' ? '' : s;
    };

    // Editor/description ko reliable tarike se fetch karo
    const getDescriptionHtml = () => {
      // 1) try native form control by name
      let html = form['proadddescription']?.value;

      // 2) try TinyMCE instance by id/name "proadddescription"
      if (!html || String(html).toLowerCase().trim() === 'undefined') {
        const tmceById = window.tinymce?.get?.('proadddescription');
        if (tmceById?.getContent) {
          html = tmceById.getContent();
        }
      }
      // 3) as a last fallback, use activeEditor if same editor is focused
      if (!html || String(html).toLowerCase().trim() === 'undefined') {
        const activeHtml = window.tinymce?.activeEditor?.getContent?.();
        if (activeHtml) html = activeHtml;
      }

      // 4) final cleanup
      html = safe(html);
      // Kabhi-kabhi "<p>undefined</p>" aa jata hai — usko sanitize:
      if (/<p>\s*undefined\s*<\/p>/i.test(html)) {
        return '';
      }
      return html;
    };

    const descriptionHtml = getDescriptionHtml();

    // Required fields
    formData.append('name', safe(form['proaddname']?.value));
    formData.append('sku', safe(form['proaddsku']?.value));
    formData.append('description', descriptionHtml); // <-- fixed here
    formData.append('metaTitle', safe(form['proaddtitle']?.value));
    formData.append('metaKeyword', 'sample-keyword');
    formData.append('metaDescription', 'sample-description');
    formData.append('price', safe(form['proaddpriceold']?.value));
    formData.append('salePrice', safe(form['proaddpricenew']?.value));
    formData.append('stock', safe(form['stock']?.value));

    // Dimensions
    formData.append('weight', '200');
    formData.append('width', '10');
    formData.append('height', '15');
    formData.append('depth', '1');

    // Categories (append ek-ek karke)
    selectedCategories.forEach((cat) => {
      formData.append('categoryId', cat.value);
    });

    // Subcategories
    selectedSubcategories.forEach((sub) => {
      formData.append('subcategoryId', sub.value);
    });

    // Images
    const mainImage = form['mainImage']?.files[0];
    if (mainImage) formData.append('mainImage', mainImage);

    const images = form['images[]']?.files;
    if (images) {
      for (let i = 0; i < images.length; i++) {
        formData.append('images', images[i]);
      }
    }

    const token = sessionStorage.getItem('authToken');
    if (!token) {
      alert('⚠️ No auth token found in sessionStorage.');
      return;
    }

    try {
      const response = await fetch('http://187.124.157.146:5001/api/products/add', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });

      const text = await response.text();
      try {
        const result = JSON.parse(text);
        if (response.ok) {
          alert('✅ Product added successfully!');
          console.log('Success:', result);
        } else {
          console.error('❌ API Error:', result);
          alert(`❌ Failed to add product: ${result?.message || 'Unknown error'}`);
        }
      } catch (err) {
        console.error('❌ Invalid JSON response:', text);
        alert('❌ Server returned an invalid response. Please check console.');
      }
    } catch (error) {
      console.error('🚫 Network Error:', error);
      alert('🚫 Error submitting form: Failed to fetch');
    }
  };

  return (
    <form onSubmit={formsubmit} encType="multipart/form-data">
      <div className="container-xxl">
        <PageHeader1 pagetitle="Products Add" button={true} />
        <div className="row g-3">
          <div className="col-xl-4 col-lg-4">
            <div className="sticky-lg-top">
              <div className="card mb-3">
                <PricingInfo />
              </div>
              <div className="card mb-3">
                <VisibilityStatus />
              </div>
              <div className="card mb-3">
                <Tags />
              </div>
              <div className="card mb-3 p-3">
                <label className="form-label fw-semibold">Categories</label>
                <Select
                  options={categoryOptions}
                  value={selectedCategories}
                  onChange={handleCategoryChange}
                  isMulti
                  isSearchable
                  placeholder="Select categories..."
                />

                <label className="form-label fw-semibold mt-3">Subcategories</label>
                {subcategoryOptions.length === 0 ? (
                  <div className="text-muted">Select categories to see subcategories</div>
                ) : (
                  <Select
                    options={subcategoryOptions}
                    value={selectedSubcategories}
                    onChange={handleSubcategoryChange}
                    isMulti
                    isSearchable
                    placeholder="Select subcategories..."
                  />
                )}
              </div>
              <div className="card">
                <InventoryInfo />
              </div>
            </div>
          </div>

          <div className="col-xl-8 col-lg-8">
            <div className="card mb-3">
              <BasicInformation />
            </div>

            <div className="card mb-3 p-3">
              <label className="form-label fw-semibold">Stock</label>
              <input type="number" name="stock" className="form-control mb-3" placeholder="Enter stock quantity" />

              <h6>Main Image</h6>
              <input type="file" name="mainImage" className="form-control mb-3" />

              <h6>Gallery Images</h6>
              <input
                type="file"
                name="images[]"
                className="form-control mb-2"
                multiple
                onChange={handleGalleryChange}
              />

              {previewUrls.length > 0 && (
                <div className="mt-3">
                  <p>Image Previews:</p>
                  <div className="d-flex flex-wrap gap-2">
                    {previewUrls.map((url, index) => (
                      <img
                        key={index}
                        src={url}
                        alt={`preview-${index}`}
                        style={{ width: '100px', height: '100px', objectFit: 'cover', border: '1px solid #ccc' }}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="text-end mt-3">
        <button type="submit" className="btn btn-primary">
          Submit
        </button>
      </div>
    </form>
  );
}

export default ProductAdd;
