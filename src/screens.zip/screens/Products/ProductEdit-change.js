import React, { useEffect, useState } from 'react';
import PageHeader1 from '../../components/common/PageHeader1';
import InventoryInfo from '../../components/Products/ProductEdit/InventoryInfo';
import Tags from '../../components/Products/ProductEdit/Tags';
import VisibilityStatus from '../../components/Products/ProductEdit/VisibilityStatus';
import { useSearchParams } from 'react-router-dom';
import axios from 'axios';
import { Editor } from '@tinymce/tinymce-react';
import Select from 'react-select';

const API_BASE = 'http://187.124.157.146:5001';

function getImageSrc(src) {
  if (!src) return '';
  if (src.startsWith('blob:')) return src;
  const clean = src.replace(/^(\/+)/, '');
  return `${API_BASE}/${clean}`;
}

function ProductEdit() {
  const [productData, setProductData] = useState({
    name:'', slug:'', description:'',
    price:'', sale_price:'', sku:'', main_image:'',
    categories:[], subcategoryId:'', weight:'', width:'', height:'', depth:''
  });
  const [categories, setCategories] = useState([]);
  const [errors, setErrors] = useState({ categories: '' });
  const [mainImageFile, setMainImageFile] = useState(null);
  const [existingImages, setExistingImages] = useState([]);
  const [selectedExisting, setSelectedExisting] = useState([]);
  const [galleryFiles, setGalleryFiles] = useState([]);
  const [galleryPreviews, setGalleryPreviews] = useState([]);
  const [searchParams] = useSearchParams();
  const productId = searchParams.get('id');

  useEffect(() => {
    const token = sessionStorage.getItem('authToken');
    if (!token) return;
    axios.get('/api/categories',{ baseURL: API_BASE, headers: { Authorization: `Bearer ${token}` } })
      .then(res => setCategories(res.data.categories || []))
      .catch(console.error);

    if (productId) {
      axios.get(`/api/products/${productId}`,{ baseURL: API_BASE, headers: { Authorization: `Bearer ${token}` } })
        .then(res => {
          const p = res.data.product || {};
          setProductData({
            name: p.name || '',
            slug: p.slug || '',
            description: p.description || '',
            price: p.price || '',
            sale_price: p.sale_price || '',
            sku: p.sku || '',
            main_image: p.main_image || '',
            categories: (p.categories||[]).map(c=>c.id.toString()),
            subcategoryId: p.subcategoryId?.toString()||'',
            weight: p.weight?.toString()||'', width: p.width?.toString()||'',
            height: p.height?.toString()||'', depth: p.depth?.toString()||''
          });
          if (Array.isArray(p.images)) setExistingImages(p.images);
        })
        .catch(console.error);
    }
  }, [productId]);

  const handleInputChange = e => {
    setProductData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleCategoryChange = opts => {
    const vals = opts.map(o=>o.value);
    setProductData(prev => ({ ...prev, categories: vals }));
    if (vals.length > 0) setErrors(prev => ({ ...prev, categories: '' }));
  };

  const handleImageChange = e => {
    const file = e.target.files[0];
    if (file) setMainImageFile(file);
  };

  const handleExistingToggle = idx => {
    setSelectedExisting(prev => prev.includes(idx) ? prev.filter(i=>i!==idx) : [...prev, idx]);
  };

  const handleGalleryChange = e => {
    const files = Array.from(e.target.files);
    setGalleryFiles(files);
    setGalleryPreviews(files.map(f => URL.createObjectURL(f)));
  };

  useEffect(() => {
    return () => galleryPreviews.forEach(URL.revokeObjectURL);
  }, [galleryPreviews]);

  const handleSubmit = async e => {
    e.preventDefault();
    if (!productData.categories?.length) {
      setErrors(prev => ({ ...prev, categories:'Please select at least one category.' }));
      return;
    }
    const token = sessionStorage.getItem('authToken');
    const formData = new FormData();
    Object.entries(productData).forEach(([k,v])=>formData.append(k,v));
    if (mainImageFile) formData.append('mainImage', mainImageFile);
    selectedExisting.forEach(idx => formData.append('existingImages', existingImages[idx]));
    galleryFiles.forEach(f => formData.append('images', f));
    try {
      await axios.put(`/api/products/update/${productId}`, formData, {
        baseURL: API_BASE,
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'multipart/form-data' }
      });
      alert('Product updated successfully!');
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.message || 'Update failed');
    }
  };

  const categoryOptions = categories.map(c => ({ value:c.id.toString(), label:c.name }));
  const selectedCatOptions = categoryOptions.filter(o=>productData.categories.includes(o.value));

  if (!productData.name && !productData.sku) return <div className="text-center mt-5">Loading product...</div>;

  return (
    <div className="container-xxl">
      <PageHeader1 pagetitle="Products Edit" button={false} />
      <form onSubmit={handleSubmit}>
        <div className="row g‑3">
          <div className="col-xl-4 col-lg-4">
            <div className="sticky-lg-top">
              <div className="card mb‑3"><div className="card-body">
                <label>Old Price</label>
                <input name="sale_price" className="form-control mb‑2" value={productData.sale_price} onChange={handleInputChange}/>
                <label>New Price</label>
                <input name="price" className="form-control" value={productData.price} onChange={handleInputChange}/>
              </div></div>
              <VisibilityStatus/>
              <Tags/>
              <div className="card mb‑3"><label className="form-label px‑3 pt‑3">Category</label>
                <div className="px‑3 pb‑3">
                  <Select isMulti options={categoryOptions} value={selectedCatOptions}
                    onChange={handleCategoryChange} classNamePrefix="react-select"
                    className={errors.categories?'is-invalid':''}/>
                  {errors.categories && <div className="text-danger px‑3" style={{fontSize:'0.875rem'}}>{errors.categories}</div>}
                </div></div>
              <div className="card mb‑3 px‑3 pt‑3">
                <label>Subcategory ID</label>
                <input name="subcategoryId" className="form-control" value={productData.subcategoryId} onChange={handleInputChange}/>
                <label className="mt‑2">Weight</label>
                <input name="weight" className="form-control" value={productData.weight} onChange={handleInputChange}/>
                <label className="mt‑2">Width</label>
                <input name="width" className="form-control" value={productData.width} onChange={handleInputChange}/>
                <label className="mt‑2">Height</label>
                <input name="height" className="form-control" value={productData.height} onChange={handleInputChange}/>
                <label className="mt‑2">Depth</label>
                <input name="depth" className="form-control" value={productData.depth} onChange={handleInputChange}/>
              </div>
              <InventoryInfo sku={productData.sku} stockQty={productData.stockQty} onChange={handleInputChange}/>
            </div>
          </div>
          <div className="col-xl-8 col-lg-8">
            <div className="card mb‑3"><div className="card-body">
              <div className="row g‑3">
                <div className="col-md-6"><label>Name</label>
                  <input name="name" className="form-control" value={productData.name} onChange={handleInputChange}/>
                </div>
                <div className="col-md-6"><label>Page Title</label>
                  <input name="name" className="form-control" value={productData.name} onChange={handleInputChange}/>
                </div>
                <div className="col-md‑12"><label>Product Slug</label>
                  <div className="input-group mb‑3">
                    <span className="input-group-text">https://continentalhome.com/productdetails/</span>
                    <input name="slug" className="form-control" value={productData.slug} onChange={handleInputChange}/>
                  </div>
                </div>
                <div className="col-md‑12"><label>Description</label>
                  <Editor apiKey="" value={productData.description}
                    onEditorChange={c=>setProductData(prev=>({...prev, description:c}))}
                    init={{height:300, menubar:false,
                      plugins:['advlist','autolink','lists','link','image','code','fullscreen','help'],
                      toolbar:'undo redo | formatselect | bold italic | alignleft aligncenter | bullist numlist'}}/>
                </div>
              </div>
            </div></div>
            <div className="card mb‑3"><div style={{padding:'1rem'}}>
              <label>Product Image</label><br/>
              <input type="file" name="main_image" onChange={handleImageChange}/>
              {productData.main_image && <img src={getImageSrc(productData.main_image)} alt="Product"
                style={{width:'400px', marginTop:10, border:'1px solid #000', borderRadius:20}}/>}
            </div></div>
            <div className="card mb‑3"><div style={{padding:'1rem'}}>
              <label>Gallery Images (select for preview)</label><br/>
              <input type="file" accept="image/*" multiple onChange={handleGalleryChange}/>
              <div style={{display:'flex', gap:'10px', flexWrap:'wrap', marginTop:'10px'}}>
                {existingImages.map((src,idx)=>(
                  <label key={idx} style={{textAlign:'center', display:'block'}}>
                    <input type="checkbox" checked={selectedExisting.includes(idx)}
                      onChange={()=>handleExistingToggle(idx)}/><br/>
                    <img src={getImageSrc(src)} alt={`Existing ${idx+1}`}
                      style={{
                        width:100, height:100, objectFit:'cover', borderRadius:8,
                        border: selectedExisting.includes(idx)? '2px solid blue':'1px solid #ccc'
                      }}/>
                  </label>
                ))}
                {galleryPreviews.map((url,idx)=>(
                  <img key={`new-${idx}`} src={url} alt={`New ${idx+1}`}
                    style={{width:100, height:100, objectFit:'cover', borderRadius:8, border:'1px solid #ccc'}}/>
                ))}
              </div>
            </div></div>
            <button type="submit" className="btn btn-primary">Update Product</button>
          </div>
        </div>
      </form>
    </div>
  );
}

export default ProductEdit;
