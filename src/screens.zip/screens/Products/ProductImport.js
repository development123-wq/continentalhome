import React, { useState } from 'react';
import axios from 'axios';

function ProductImport() {
  const [file, setFile] = useState(null);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleImport = async () => {
    if (!file) {
      alert("Please select a file first.");
      return;
    }

    const formData = new FormData();
    formData.append('file', file);

    // 👇 Token should already be stored in localStorage
    const token = sessionStorage.getItem("authToken");

    if (!token) {
      alert("Authorization token not found. Please login again.");
      return;
    }

    try {
      const response = await axios.post('http://187.124.157.146:5001/api/products/import-csv', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${token}`,
        },
      });

      alert('✅ Products imported successfully!');
      console.log(response.data);
    } catch (error) {
      console.error(error);
      alert(`❌ Failed to import products. (${error.response?.status || 'Unknown error'})`);
    }
  };

  return (
    <div
      style={{
        backgroundColor: '#f3f4f6',
        minHeight: '70vh',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        fontFamily: 'Arial, sans-serif',
      }}
    >
      <div
        style={{
          backgroundColor: '#ffffff',
          padding: '40px',
          borderRadius: '10px',
          boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
          width: '100%',
          maxWidth: '500px',
          textAlign: 'center',
        }}
      >
        <h2
          style={{
            fontSize: '26px',
            fontWeight: 'bold',
            color: '#1f2937',
            marginBottom: '20px',
          }}
        >
          Import Products via CSV
        </h2>

        <input
          type="file"
          onChange={handleFileChange}
          accept=".csv,.xlsx"
          style={{
            marginBottom: '20px',
            display: 'block',
            marginLeft: 'auto',
            marginRight: 'auto',
          }}
        />

        <button
          onClick={handleImport}
          style={{
            padding: '10px 20px',
            backgroundColor: '#63a682',
            color: '#ffffff',
            border: 'none',
            borderRadius: '5px',
            fontSize: '16px',
            cursor: 'pointer',
          }}
        >
          Import
        </button>
        <br /><br />

        <a
          href="/public/csv/product_csv_sample.csv"
          style={{
            padding: '10px 20px',
            backgroundColor: '#63a682',
            color: '#ffffff',
            border: 'none',
            borderRadius: '5px',
            fontSize: '16px',
            cursor: 'pointer',
            textDecoration: 'none',
            display: 'inline-block',
          }}
          target="_blank"
          download="product_csv_sample.csv"
        >
          Download Sample Sheet
        </a>
      </div>
    </div>
  );
}

export default ProductImport;
