import React from 'react';
import CategoriesBlock from '../../components/Products/ProductList/CategoriesBlock';
import SizeBlock from '../../components/Products/ProductList/SizeBlock';
import ColorBlock from '../../components/Products/ProductList/ColorBlock';
import PricingBlock from '../../components/Products/ProductList/PricingBlock';
import RatingBlock from '../../components/Products/ProductList/RatingBlock';
import CardBlock from '../../components/Products/ProductList/CardBlock';
import PageHeader1 from '../../components/common/PageHeader1';

function ProductList() {
    return (
        <div className="container-xxl">
            <PageHeader1 pagetitle='Products List' productlist={false} />
            <div className="row g-3 mb-3">
                
                <div className="col-md-12 col-lg-12 col-xl-12 col-xxl-12">
                    <CardBlock />
                </div>
                
            </div>
        </div>
    )
}
export default ProductList;