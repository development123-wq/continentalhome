import React, { useEffect, useState } from 'react';
import PageHeader1 from '../../components/common/PageHeader1';
import InventoryInfo from '../../components/Products/ProductEdit/InventoryInfo';
import Tags from '../../components/Products/ProductEdit/Tags';
import VisibilityStatus from '../../components/Products/ProductEdit/VisibilityStatus';
import { useSearchParams } from 'react-router-dom';
import axios from 'axios';
import { Editor } from '@tinymce/tinymce-react';
import Select from 'react-select';

function ProductEdit() {
  const [productData, setProductData] = useState({
    name: '',
    price: '',
    sale_price: '', // state key same rakha hai; UI me isi se bind hoga
    sku: '',
    description: '',
    slug: '',
    main_image: '',
    categories: [],
    subcategoryId: '',
    weight: '',
    width: '',
    height: '',
    depth: '',
    galleryImages: [],
    stock: '',
    id: '',
    pageTitle: '',
  });

  // Keep original API values (fallback)
  const [originalPrice, setOriginalPrice] = useState({ price: '', sale_price: '' });

  const [mainImageFile, setMainImageFile] = useState(null);
  const [galleryFiles, setGalleryFiles] = useState([]);
  const [categories, setCategories] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
  const [searchParams] = useSearchParams();
  const productId = searchParams.get('id');

  useEffect(() => {
    const token = sessionStorage.getItem("authToken");

    if (token) {
      axios.get('http://187.124.157.146:5001/api/categories', {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then(res => setCategories(res.data.categories || []))
      .catch(err => console.error("Error fetching categories:", err));
    }

    if (productId && token) {
      axios.get(`http://187.124.157.146:5001/api/products/${productId}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then((res) => {
        const product = res.data?.product || {};

        // Read sale price from either sale_price or salePrice (fallback)
        const salePriceFromApi = (product.sale_price ?? product.salePrice ?? '');

        setProductData({
          name: product.name || '',
          price: product.price ?? '',
          sale_price: salePriceFromApi,
          sku: product.sku || '',
          description: product.description || '',
          slug: product.slug || '',
          main_image: product.main_image || '',
          categories: product.categories?.map(c => c.id.toString()) || [],
          subcategoryId: product.subcategories?.[0]?.id?.toString() || '',
          weight: product.weight ?? '',
          width: product.width ?? '',
          height: product.height ?? '',
          depth: product.depth ?? '',
          galleryImages: product.images || [],
          stock: product.stock ?? '',
          id: product.id || '',
          pageTitle: product.name || '',
        });

        setOriginalPrice({
          price: product.price ?? '',
          sale_price: salePriceFromApi,
        });

        setSubcategories(product.subcategories || []);
      })
      .catch((err) => {
        console.error("Error fetching product:", err);
      });
    }
  }, [productId]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProductData(prev => ({ ...prev, [name]: value }));
  };

  const handleCategoryChange = (selectedOptions) => {
    const selectedValues = selectedOptions.map(option => option.value);
    setProductData(prev => ({ ...prev, categories: selectedValues }));
  };

  const handleSubCategoryChange = (selectedOption) => {
    setProductData(prev => ({
      ...prev,
      subcategoryId: selectedOption ? selectedOption.value : ''
    }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) setMainImageFile(file);
  };

  const handleGalleryChange = (e) => {
    const files = Array.from(e.target.files);
    setGalleryFiles(files);
    setProductData(prev => ({
      ...prev,
      galleryImages: files.map(file => URL.createObjectURL(file))
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = sessionStorage.getItem("authToken");
    const formData = new FormData();

    const clean = (v) => (v ?? '').toString().trim();
    const moneyOrOriginal = (current, original) => {
      const v = clean(current);
      if (v === '' || Number(v) <= 0 || Number.isNaN(Number(v))) {
        return clean(original);
      }
      return v;
    };

    const priceToSend = moneyOrOriginal(productData.price, originalPrice.price);
    const salePriceToSend = moneyOrOriginal(productData.sale_price, originalPrice.sale_price);

    formData.append("name", productData.name);
    formData.append("sku", productData.sku);
    formData.append("price", priceToSend);

    // IMPORTANT: send camelCase param for update
    formData.append("salePrice", salePriceToSend);

    formData.append("weight", clean(productData.weight) || "1");
    formData.append("width", clean(productData.width) || "1");
    formData.append("height", clean(productData.height) || "1");
    formData.append("depth", clean(productData.depth) || "1");
    formData.append("categoryId", productData.categories.length ? productData.categories.join(',') : '');
    formData.append("subcategoryId", productData.subcategoryId || '');
    formData.append("description", productData.description || '');
    formData.append("stock", clean(productData.stock) !== '' ? clean(productData.stock) : '0');

    try {
      // Keep existing main image if not changed
      if (!mainImageFile && productData.main_image) {
        const response = await fetch(`http://187.124.157.146:5001/${productData.main_image}`);
        const blob = await response.blob();
        const fileName = productData.main_image.split('/').pop();
        const file = new File([blob], fileName, { type: blob.type });
        formData.append("mainImage", file);
      } else if (mainImageFile) {
        formData.append("mainImage", mainImageFile);
      }

      // Append gallery images if selected
      if (galleryFiles.length > 0) {
        galleryFiles.forEach((file) => {
          formData.append("images", file);
        });
      }

      await axios.put(
        `http://187.124.157.146:5001/api/products/update/${productId}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'multipart/form-data'
          }
        }
      );

      alert("✅ Product updated successfully!");
    } catch (error) {
      console.error("❌ Error updating product:", error);
      alert("Failed to update product.");
    }
  };

  const categoryOptions = categories.map(cat => ({
    value: cat.id.toString(),
    label: cat.name
  }));

  const subCategoryOptions = subcategories.map(sub => ({
    value: sub.id.toString(),
    label: sub.name
  }));

  const selectedCategoryOptions = categoryOptions.filter(option =>
    productData.categories.includes(option.value)
  );

  const selectedSubCategoryOption = subCategoryOptions.find(option =>
    option.value === productData.subcategoryId
  ) || null;

  if (!productData.name && !productData.sku) {
    return <div className="text-center mt-5">Loading product...</div>;
  }

  return (
    <div className="container-xxl">
      <PageHeader1 pagetitle='Products Edit' button={false} />
      <form onSubmit={handleSubmit}>
        <div className="row g-3">
          <div className="col-xl-4 col-lg-4">
            <div className="sticky-lg-top">
              <div className="card mb-3">
                <div className="card-body">
                  <label className="form-label">Product Price New</label>
                  <input
                    type="number"
                    min="1"
                    step="0.01"
                    className="form-control mb-2"
                    name="sale_price"
                    value={productData.sale_price}
                    onChange={handleInputChange}
                  />
                  <label className="form-label">Product Price Old</label>
                  <input
                    type="number"
                    min="1"
                    step="0.01"
                    className="form-control"
                    name="price"
                    value={productData.price}
                    onChange={handleInputChange}
                  />
                </div>
              </div>

              <div className="card mb-3">
                <VisibilityStatus />
              </div>

              <div className="card mb-3">
                <label className="form-label px-3 pt-3">Category</label>
                <div className="px-3 pb-3">
                  <Select
                    isMulti
                    options={categoryOptions}
                    value={selectedCategoryOptions}
                    onChange={handleCategoryChange}
                    placeholder="Select categories"
                  />
                </div>
                <label className="form-label px-3 pt-3">Sub Category</label>
                <div className="px-3 pb-3">
                  <Select
                    isClearable
                    options={subCategoryOptions}
                    value={selectedSubCategoryOption}
                    onChange={handleSubCategoryChange}
                    placeholder="Select subcategory"
                  />
                </div>
              </div>

              <div className="card mb-3 px-3 pt-3">
                <label className="form-label mt-2">Weight</label>
                <input type="text" className="form-control" name="weight" value={productData.weight} onChange={handleInputChange} />
                <label className="form-label mt-2">Width</label>
                <input type="text" className="form-control" name="width" value={productData.width} onChange={handleInputChange} />
                <label className="form-label mt-2">Height</label>
                <input type="text" className="form-control" name="height" value={productData.height} onChange={handleInputChange} />
                <label className="form-label mt-2">Depth</label>
                <input type="text" className="form-control" name="depth" value={productData.depth} onChange={handleInputChange} />
              </div>

              <div className="card mb-3">
                <InventoryInfo
                  sku={productData.sku}
                  stockQty={productData.stock}
                  onChange={handleInputChange}
                />
              </div>
            </div>
          </div>

          <div className="col-xl-8 col-lg-8">
            <div className="card mb-3">
              <div className="card-body">
                <div className="row g-3">
                  <div className="col-md-6">
                    <label className="form-label">Name</label>
                    <input type="text" className="form-control" name="name" value={productData.name} onChange={handleInputChange} />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Page Title</label>
                    <input type="text" className="form-control" name="pageTitle" value={productData.pageTitle} onChange={handleInputChange} />
                  </div>
                  <div className="col-md-12">
                    <label className="form-label">Product Slug</label>
                    <div className="input-group mb-3">
                      <span className="input-group-text">https://continentalhome.com/productdetails?id={productData.id}</span>
                    </div>
                  </div>
                  <div className="col-md-12">
                    <label className="form-label">Product Description</label>
                    <Editor
                      apiKey="ewqu5ti6bsjbxirh6rptpf3m05mwek075mt56suan91l8exv"
                      value={productData.description}
                      onEditorChange={(content) => setProductData(prev => ({ ...prev, description: content }))}
                      init={{
                        height: 300,
                        menubar: false,
                        plugins: [
                          'advlist autolink lists link image charmap print preview anchor',
                          'searchreplace visualblocks code fullscreen',
                          'insertdatetime media table paste code help wordcount'
                        ],
                        toolbar:
                          'undo redo | formatselect | bold italic backcolor | ' +
                          'alignleft aligncenter alignright alignjustify | ' +
                          'bullist numlist outdent indent | removeformat | help'
                      }}
                    />
                    <div className="col-md-12 mt-3">
                      <label className="form-label">Stock Quantity</label>
                      <input
                        type="number"
                        className="form-control"
                        name="stock"
                        value={productData.stock || ''}
                        onChange={handleInputChange}
                        min={0}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="card mb-3" style={{ padding: '1rem' }}>
              <label className="form-label">Main Product Image</label><br />
              <input type="file" name="main_image" onChange={handleImageChange} />
              {productData.main_image && (
                <img
                  src={`http://187.124.157.146:5001/${productData.main_image}`}
                  style={{ width: '300px', border: '1px solid #000', marginTop: '10px', borderRadius: '20px' }}
                  alt="Product"
                />
              )}
            </div>

            <div className="card mb-3" style={{ padding: '1rem' }}>
              <label className="form-label">Gallery Images</label><br />
              <input type="file" name="gallery_images" multiple onChange={handleGalleryChange} />
              <div className="mt-3 d-flex flex-wrap gap-3">
                {productData.galleryImages?.map((img, i) => (
                  <img
                    key={i}
                    src={typeof img === 'string' && !img.startsWith('blob:') ? `http://187.124.157.146:5001/${img}` : img}
                    style={{ width: '120px', height: '120px', objectFit: 'cover', borderRadius: '8px', border: '1px solid #ccc' }}
                    alt={`Gallery ${i}`}
                  />
                ))}
              </div>
            </div>

            <button type="submit" className="btn btn-primary">Update Product</button>
          </div>
        </div>
      </form>
    </div>
  );
}

export default ProductEdit;
