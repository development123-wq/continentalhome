import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import PageHeader1 from '../../components/common/PageHeader1';
import AddressBlock from '../../components/Customers/CustomerDetails/AddressBlock';
import ExpenseCountBlock from '../../components/Customers/CustomerDetails/ExpenseCountBlock';
import StatusReport from '../../components/Customers/CustomerDetails/StatusReport';
import { useLocation } from 'react-router-dom';

function CustomerDetail() {
  const [customer, setCustomer] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const customerId = queryParams.get('id');

  useEffect(() => {
    if (!customerId) return;

    const token = sessionStorage.getItem('authToken');

    setLoading(true);
    fetch(`http://187.124.157.146:5001/api/customers/${customerId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    })
      .then((res) => {
        if (!res.ok) throw new Error('Failed to fetch customer data');
        return res.json();
      })
      .then((data) => {
        setCustomer(data.customer);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, [customerId]);

  return (
    <div className="body d-flex py-3">
      <div className="container-xxl">
        <PageHeader1 pagetitle="Customer Detail" />

        {loading ? (
          <div>Loading...</div>
        ) : error ? (
          <div>Error: {error}</div>
        ) : (
          <>
            {/* ✅ Customer Basic Info */}
            <div className="mb-3 card auth-detailblock" style={{ padding: '1rem' }}>
              <h5>
                <b>
                  {customer.first_name} {customer.last_name}
                </b>
              </h5>
              <p>
                <b>Email: </b>
                {customer.email}
              </p>
              <p>
                <b>Phone:</b> {customer.phone}
              </p>
              <p>
                <b>Company:</b> {customer.company}
              </p>
              <p>
                <b>Group:</b> {customer.customer_group}
              </p>
              <p>
                <b>ID:</b> {customer.customer_id}
              </p>
            </div>

            {/* ✅ Address Block */}
            <AddressBlock
              address={{
                line1: customer.address_line1_1,
                line2: customer.address_line2_1,
                city: customer.address_city_1,
                state: customer.address_state_1,
                zip: customer.address_zip_1,
                country: customer.address_country_1,
                phone: customer.address_phone_1,
              }}
            />

            {/* ✅ Orders Section */}
            <div className="card mt-3">
              <div className="card-header py-3 d-flex justify-content-between bg-transparent border-bottom-0">
                <h6 className="mb-0 fw-bold">Customer Orders</h6>
              </div>
              <div className="card-body">
                <CustomerOrders customerId={customerId} />
              </div>
            </div>

            {/* 🧾 Summary Sections */}
            <div className="row mt-3">
              {/* <div className="col-lg-6">
                <ExpenseCountBlock orders={[]} />
              </div> */}
              <div className="col-lg-12">
                <StatusReport customer={customer} orders={[]} />
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default CustomerDetail;

function CustomerOrders({ customerId }) {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!customerId) return;

    const token = sessionStorage.getItem('authToken');

    setLoading(true);
    fetch(`http://187.124.157.146:5001/api/orders/customer/${customerId}?page=1&limit=100`, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    })
      .then((res) => {
        if (!res.ok) throw new Error('Failed to fetch orders');
        return res.json();
      })
      .then((data) => {
        setOrders(data.orders || []);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, [customerId]);

  const orderColumns = [
    { name: 'Order ID', selector: (row) => row.id, sortable: true },
    
    { name: 'Amount', selector: (row) => row.order_total_inc_tax || 'N/A', sortable: true },
    { name: 'Status', selector: (row) => row.order_status || 'N/A', sortable: true },
  ];

  if (loading) return <div>Loading orders...</div>;
  if (error) return <div>Error loading orders: {error}</div>;

  return orders.length > 0 ? (
    <DataTable
      columns={orderColumns}
      data={orders}
      pagination
      highlightOnHover
      className="table myDataTable table-hover align-middle mb-0 d-row nowrap dataTable no-footer dtr-inline"
    />
  ) : (
    <div>No orders found.</div>
  );
}
