import React, { useState, useEffect } from 'react';
import { Modal } from 'react-bootstrap';
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom';
import PageHeader1 from '../../components/common/PageHeader1';

function CustomerList() {
  const [customers, setCustomers] = useState([]);
  const [filteredCustomers, setFilteredCustomers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [page, setPage] = useState(1);
  const [totalRows, setTotalRows] = useState(0);

  const navigate = useNavigate();

  useEffect(() => {
    setLoading(true);
    fetch(`http://187.124.157.146:5001/api/customers?page=${page}&limit=${rowsPerPage}`)
      .then((response) => {
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        return response.json();
      })
      .then((data) => {
        if (data && Array.isArray(data.customers)) {
          setCustomers(data.customers);
          setFilteredCustomers(data.customers); 
          setTotalRows(data.total || 0);
        } else {
          setError('Data format is incorrect');
        }
        setLoading(false);
      })
      .catch((error) => {
        setError(error.message);
        setLoading(false);
      });
  }, [page, rowsPerPage]);

  useEffect(() => {
    const filtered = customers.filter((c) =>
      (`${c.first_name} ${c.last_name}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.phone?.toLowerCase().includes(searchTerm.toLowerCase()))
    );
    setFilteredCustomers(filtered);
  }, [searchTerm, customers]);

  const handleRowClick = (row) => {
    navigate(`/customer-detail?id=${row.id}`);
  };

  const handlePageChange = (newPage) => setPage(newPage);
  const handleRowsPerPageChange = (newRowsPerPage) => {
    setRowsPerPage(newRowsPerPage);
    setPage(1);
  };

  const columns = [
    { name: 'ID', selector: row => `#${row.id}`, sortable: true },
    { name: 'Name', selector: row => `${row.first_name} ${row.last_name}`, sortable: true },
    { name: 'Email', selector: row => row.email, sortable: true },
    { name: 'Phone', selector: row => row.phone, sortable: true },
    { name: 'Register Date', selector: row => row.company, sortable: true },
  ];

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div className="body d-flex py-3">
      <div className="container-xxl">
        <PageHeader1 pagetitle="Customers Information" />
        <style>{`
  #pagination-first-page, #pagination-previous-page, #pagination-next-page, #pagination-last-page {
    display: none !important;
  }
    select
    {
    border:1px solid #000;pdding:5px;border-radius:2px;
    }
`}</style>
        <div className="row g-3 mb-3">
          <div className="col-md-12">
            <div className="card">
              <div className="card-body">

                {/* 🔍 Search Box */}
                <div className="mb-3">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search by name, email, or phone"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>

                <DataTable
                  columns={columns}
                  data={filteredCustomers}
                  pagination
                  paginationServer
                  paginationTotalRows={totalRows}
                  paginationPerPage={rowsPerPage}
                  paginationRowsPerPageOptions={[10, 25, 50, 100, 250, 500]}
                  onChangePage={handlePageChange}
                  onChangeRowsPerPage={handleRowsPerPageChange}
                  highlightOnHover
                  pointerOnHover
                  onRowClicked={handleRowClick}
                  className="table myDataTable table-hover align-middle mb-0 d-row nowrap dataTable no-footer dtr-inline"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CustomerList;
