import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Subscribers = () => {
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);
  const [noToken, setNoToken] = useState(false);

  useEffect(() => {
    const fetchSubscribers = async () => {
      const token = sessionStorage.getItem('authToken');
      console.log('🔐 Token from session:', token);

      if (!token) {
        setNoToken(true);
        return;
      }

      setLoading(true);
      try {
        const response = await axios.get(
          'http://187.124.157.146:5001/api/stats/allubscribers',
          {
            headers: {
              Authorization: `Bearer ${token}`,
              'Content-Type': 'application/json',
            },
          }
        );

        console.log('✅ Raw API response:', response.data);

        const raw = response.data;
        let list = [];

        if (Array.isArray(raw)) list = raw;
        else if (Array.isArray(raw.data)) list = raw.data;
        else if (Array.isArray(raw.subscribers)) list = raw.subscribers;
        else if (Array.isArray(raw.results)) list = raw.results;

        setData(list);
      } catch (error) {
        console.error('❌ API Error:', {
          message: error.message,
          status: error.response?.status,
          data: error.response?.data,
        });
      } finally {
        setLoading(false);
      }
    };

    fetchSubscribers();
  }, []);

  const filteredData = data.filter(user =>
    user.email?.toLowerCase().includes(search.toLowerCase())
  );

  const exportCSV = () => {
    const csvHeader = ['S.No.', 'Email'];
    const csvRows = filteredData.map((user, idx) => [idx + 1, user.email]);
    const csvContent =
      [csvHeader, ...csvRows]
        .map(row => row.map(val => `"${val || ''}"`).join(','))
        .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'subscribers.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div style={{ padding: 30, fontFamily: 'Segoe UI, sans-serif', backgroundColor: '#fff' }}>
      <h2 style={{ fontSize: 24, marginBottom: 5 }}>Subscribers</h2>

      {noToken ? (
        <p style={{ color: '#d00' }}>Token not found. Please login first.</p>
      ) : (
        <>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 20 }}>
            <input
              type="text"
              placeholder="Search by email"
              value={search}
              onChange={e => setSearch(e.target.value)}
              style={{
                width: '70%',
                padding: '12px 16px',
                border: '1px solid #ccc',
                borderRadius: 10,
                fontSize: 16,
                boxSizing: 'border-box',
              }}
            />
            <button
              onClick={exportCSV}
              style={{
                padding: '12px 24px',
                backgroundColor: '#63a682',
                color: '#fff',
                border: 'none',
                borderRadius: 8,
                fontSize: 16,
                cursor: 'pointer',
              }}
            >
              Export CSV
            </button>
          </div>

          {loading ? (
            <p style={{ textAlign: 'center' }}>Loading…</p>
          ) : filteredData.length === 0 ? (
            <p style={{ color: '#999', textAlign: 'center' }}>No subscribers found.</p>
          ) : (
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 16 }}>
              <thead>
                <tr style={{ textAlign: 'left', borderBottom: '2px solid #ccc' }}>
                  <th style={{ padding: '14px 10px', fontWeight: 600 }}>S.No.</th>
                  <th style={{ padding: '14px 10px', fontWeight: 600 }}>Email</th>
                </tr>
              </thead>
              <tbody>
                {filteredData.map((user, idx) => (
                  <tr
                    key={user.id || idx}
                    style={{ borderBottom: '1px solid #eee'}}
                    
                  >
                    <td style={{ padding: '14px 10px' }}>{idx + 1}</td>
                    <td style={{ padding: '14px 10px' }}>{user.email}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </>
      )}
    </div>
  );
};

export default Subscribers;
