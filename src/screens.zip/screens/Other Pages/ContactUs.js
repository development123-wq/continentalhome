import React, { useEffect, useState } from 'react';
import { Col, Row, Tab, Form, Button } from 'react-bootstrap';
import PageHeader1 from '../../components/common/PageHeader1';
import axios from 'axios';

function ContactUs() {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    phone: '',
    email: '',
    address: '',
    mapContent: '',
    bannerImage: null,
  });

  useEffect(() => {
    axios.get('http://187.124.157.146:5001/api/contact')
      .then(res => {
        const data = res.data;
        setFormData(prev => ({
          ...prev,
          title: data.title || '',
          description: data.description || '',
          phone: data.phone || '',
          email: data.email || '',
          address: data.address || '',
          mapContent: data.mapContent || '',
        }));
      })
      .catch(err => {
        console.error('GET error:', err);
      });
  }, []);

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleFileChange = (e) => {
    setFormData(prev => ({
      ...prev,
      bannerImage: e.target.files[0]
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const payload = new FormData();
    payload.append('title', formData.title);
    payload.append('description', formData.description);
    payload.append('phone', formData.phone);
    payload.append('email', formData.email);
    payload.append('address', formData.address);
    payload.append('mapContent', formData.mapContent);

    if (formData.bannerImage) {
      payload.append('bannerImage', formData.bannerImage);
    }

    try {
      const token = sessionStorage.getItem('authToken');

      const response = await axios.put(
        'http://187.124.157.146:5001/api/contact/update/1',
        payload,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'multipart/form-data'
          }
        }
      );

      alert("Contact updated successfully!");
    } catch (error) {
      console.error("Update error:", error.response?.data || error.message);
      alert(error.response?.data?.message || "Something went wrong!");
    }
  };

  return (
    <div className='body d-flex py-3'>
      <div className='container-xxl'>
        <Tab.Container defaultActiveKey="first">
          <Row>
            <Col sm={12}>
              {/* <PageHeader1 pagetitle='Contact' cantactus={false} /> */}
            </Col>
            <Col sm={12}>
              <h2 className="mb-4">Update Contact Us</h2>
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3">
                  <Form.Label>Title</Form.Label>
                  <Form.Control type="text" name="title" value={formData.title} onChange={handleChange} required />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Description</Form.Label>
                  <Form.Control as="textarea" rows={3} name="description" value={formData.description} onChange={handleChange} required />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Banner Image</Form.Label>
                  <Form.Control type="file" name="bannerImage" onChange={handleFileChange}  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Phone</Form.Label>
                  <Form.Control type="text" name="phone" value={formData.phone} onChange={handleChange} required />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Email</Form.Label>
                  <Form.Control type="email" name="email" value={formData.email} onChange={handleChange} required />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Address</Form.Label>
                  <Form.Control as="textarea" rows={2} name="address" value={formData.address} onChange={handleChange} required />
                </Form.Group>

                <Form.Group className="mb-4">
                  <Form.Label>Map Content</Form.Label>
                  <Form.Control as="textarea" rows={2} name="mapContent" value={formData.map_content} onChange={handleChange} />
                </Form.Group>

                <Button variant="primary" type="submit">
                  Update
                </Button>
              </Form>
            </Col>
          </Row>
        </Tab.Container>
      </div>
    </div>
  );
}

export default ContactUs;
