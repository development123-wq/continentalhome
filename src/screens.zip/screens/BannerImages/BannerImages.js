import React, { useEffect, useState, useCallback } from "react";

const API_BASE = "http://187.124.157.146:5001";
const BANNERS_API = `${API_BASE}/api/banners`;
const BANNERS_CREATE_API = `${API_BASE}/api/banners/create`;
const BANNERS_UPDATE_API = (id) => `${API_BASE}/api/banners/update/${id}`;
const BANNERS_DELETE_API = (id) => `${API_BASE}/api/banners/delete/${id}`;

// Multer me file field ka exact naam uncertain — in keys ko order me try karenge:
const FILE_FIELD_CANDIDATES = [
  "image",
  "images",
  "banner",
  "bannerImage",
  "file",
  "photo",
  "img",
  "banner_image",
];

// Kuch servers PUT par file accept nahi karte — to methods bhi fallback:
const METHOD_CANDIDATES = ["PUT", "POST", "PATCH"];

const BannerImages = () => {
  // ----- List states -----
  const [banners, setBanners] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  // ----- Add form states -----
  const [title, setTitle] = useState("");
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitMsg, setSubmitMsg] = useState("");

  // ----- Edit states (inline) -----
  const [editId, setEditId] = useState(null);
  const [editTitle, setEditTitle] = useState("");
  const [editFile, setEditFile] = useState(null);
  const [editPreview, setEditPreview] = useState("");
  const [editSubmitting, setEditSubmitting] = useState(false);
  const [editMsg, setEditMsg] = useState("");

  // ----- Delete states -----
  const [deletingId, setDeletingId] = useState(null);
  const [deleteMsg, setDeleteMsg] = useState("");

  const toAbsolute = (path) => {
    if (!path) return "";
    if (/^https?:\/\//i.test(path)) return path;
    const rel = path.startsWith("/") ? path.slice(1) : path;
    return `${API_BASE}/${rel}`;
  };

  const fetchBanners = useCallback(async () => {
    setLoading(true);
    setErr("");
    try {
      const token = sessionStorage.getItem("authToken"); // if protected
      const res = await fetch(BANNERS_API, {
        headers: token ? { Authorization: `Bearer ${token}` } : undefined,
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const list = Array.isArray(data) ? data : [];
      setBanners(list);
    } catch (e) {
      setErr(e?.message || "Failed to load banners");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchBanners();
  }, [fetchBanners]);

  // ---------- ADD HANDLERS ----------
  const onFileChange = (e) => {
    const f = e.target.files?.[0] || null;
    setFile(f);
    if (f) setPreview(URL.createObjectURL(f));
    else setPreview("");
  };

  useEffect(() => {
    return () => {
      if (preview) URL.revokeObjectURL(preview);
    };
  }, [preview]);

  const resetAddForm = () => {
    setTitle("");
    setFile(null);
    if (preview) URL.revokeObjectURL(preview);
    setPreview("");
    setSubmitMsg("");
    const fileInput = document.getElementById("bannerImageInput");
    if (fileInput) fileInput.value = "";
  };

  const handleAddBanner = async (e) => {
    e.preventDefault();
    setSubmitMsg("");

    if (!title.trim()) return setSubmitMsg("Please enter a title.");
    if (!file) return setSubmitMsg("Please select an image file.");

    const allowed = ["image/jpeg", "image/png", "image/webp"];
    if (!allowed.includes(file.type)) {
      return setSubmitMsg("Only JPG, PNG, or WebP images are allowed.");
    }

    setSubmitting(true);
    const token = sessionStorage.getItem("authToken");
    let lastError = "";
    let success = false;

    for (const fieldName of FILE_FIELD_CANDIDATES) {
      try {
        const formData = new FormData();
        formData.append("title", title.trim());
        formData.append(fieldName, file);

        const res = await fetch(BANNERS_CREATE_API, {
          method: "POST",
          headers: token ? { Authorization: `Bearer ${token}` } : undefined,
          body: formData,
        });

        const text = await res.text();
        let json = null;
        try { json = JSON.parse(text); } catch {}

        if (!res.ok) {
          if (String(text).includes("MulterError: Unexpected field")) {
            lastError = `Unexpected field for key "${fieldName}"`;
            continue;
          }
          throw new Error(json?.message || text || `HTTP ${res.status}`);
        }

        setSubmitMsg("✅ Banner added successfully!");
        resetAddForm();
        await fetchBanners();
        success = true;
        break;
      } catch (err) {
        lastError = err?.message || "Unknown error";
      }
    }

    if (!success) {
      setSubmitMsg(`❌ Failed to add banner: ${lastError || "Server rejected all field names"}`);
    }
    setSubmitting(false);
  };

  // ---------- EDIT HANDLERS ----------
  const startEdit = (banner) => {
    setEditMsg("");
    setEditId(banner.id);
    setEditTitle(banner.title || "");
    setEditFile(null);
    if (editPreview) URL.revokeObjectURL(editPreview);
    setEditPreview("");
  };

  const cancelEdit = () => {
    setEditId(null);
    setEditTitle("");
    if (editPreview) URL.revokeObjectURL(editPreview);
    setEditPreview("");
    setEditFile(null);
    setEditSubmitting(false);
    setEditMsg("");
  };

  const onEditFileChange = (e) => {
    const f = e.target.files?.[0] || null;
    setEditFile(f);
    if (editPreview) URL.revokeObjectURL(editPreview);
    if (f) setEditPreview(URL.createObjectURL(f));
    else setEditPreview("");
  };

  const handleUpdateBanner = async (e) => {
    e.preventDefault();
    if (!editId) return;
    setEditMsg("");

    if (!editTitle.trim()) {
      setEditMsg("Please enter a title.");
      return;
    }

    if (editFile) {
      const allowed = ["image/jpeg", "image/png", "image/webp"];
      if (!allowed.includes(editFile.type)) {
        setEditMsg("Only JPG, PNG, or WebP images are allowed.");
        return;
      }
    }

    setEditSubmitting(true);
    const token = sessionStorage.getItem("authToken");
    const url = BANNERS_UPDATE_API(editId);
    let outerLastError = "";
    let success = false;

    for (const method of METHOD_CANDIDATES) {
      let lastError = "";
      const fileKeys = editFile ? FILE_FIELD_CANDIDATES : [null];

      for (const fieldName of fileKeys) {
        try {
          const formData = new FormData();
          formData.append("title", editTitle.trim());
          if (editFile && fieldName) formData.append(fieldName, editFile);

          const res = await fetch(url, {
            method,
            headers: token ? { Authorization: `Bearer ${token}` } : undefined,
            body: formData,
          });

          const text = await res.text();
          let json = null;
          try { json = JSON.parse(text); } catch {}

          if (!res.ok) {
            const str = String(text);
            if (str.includes("MulterError: Unexpected field")) {
              lastError = `Unexpected field for key "${fieldName}" via ${method}`;
              continue;
            }
            if (res.status === 405) {
              lastError = `Method ${method} not allowed`;
              break;
            }
            throw new Error(json?.message || text || `HTTP ${res.status}`);
          }

          setEditMsg("✅ Banner updated successfully!");
          await fetchBanners();
          cancelEdit();
          success = true;
          break;
        } catch (err) {
          lastError = err?.message || "Unknown error";
        }
      }
      if (success) break;
      outerLastError = lastError || outerLastError;
    }

    if (!success) {
      setEditMsg(`❌ Failed to update banner: ${outerLastError || "Server rejected request"}`);
    }
    setEditSubmitting(false);
  };

  // ---------- DELETE HANDLER ----------
  const handleDeleteBanner = async (banner) => {
    setDeleteMsg("");
    if (!banner?.id) return;

    const ok = window.confirm(`Delete banner "${banner.title || banner.id}"? This cannot be undone.`);
    if (!ok) return;

    setDeletingId(banner.id);
    const token = sessionStorage.getItem("authToken");
    const url = BANNERS_DELETE_API(banner.id);
    let success = false;
    let lastError = "";

    try {
      // Try DELETE without body
      let res = await fetch(url, {
        method: "DELETE",
        headers: token ? { Authorization: `Bearer ${token}` } : undefined,
      });
      if (!res.ok) {
        // Try POST without body
        res = await fetch(url, {
          method: "POST",
          headers: token ? { Authorization: `Bearer ${token}` } : undefined,
        });
      }
      if (!res.ok) {
        // Try POST with form-data id
        const fd1 = new FormData();
        fd1.append("id", String(banner.id));
        res = await fetch(url, {
          method: "POST",
          headers: token ? { Authorization: `Bearer ${token}` } : undefined,
          body: fd1,
        });
      }
      if (!res.ok) {
        // Try POST with bannerId
        const fd2 = new FormData();
        fd2.append("bannerId", String(banner.id));
        res = await fetch(url, {
          method: "POST",
          headers: token ? { Authorization: `Bearer ${token}` } : undefined,
          body: fd2,
        });
      }

      const text = await res.text();
      let json = null;
      try { json = JSON.parse(text); } catch {}
      if (!res.ok) {
        throw new Error(json?.message || text || `HTTP ${res.status}`);
      }

      success = true;
    } catch (e) {
      lastError = e?.message || "Unknown error";
    } finally {
      setDeletingId(null);
    }

    if (success) {
      setDeleteMsg("✅ Banner deleted successfully!");
      await fetchBanners();
      // Clear the message after a while
      setTimeout(() => setDeleteMsg(""), 3000);
    } else {
      setDeleteMsg(`❌ Failed to delete: ${lastError}`);
    }
  };

  // ---------- UI ----------
  return (
    <div className="container-xxl">
      {/* ADD BANNER */}
      <div className="card my-3">
        <div className="card-body">
          <h2 className="h5 mb-3">Add New Banner</h2>
          <form onSubmit={handleAddBanner}>
            <div className="row g-3 align-items-end">
              <div className="col-12 col-md-4">
                <label className="form-label">Title</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter banner title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  disabled={submitting}
                />
              </div>
              <div className="col-12 col-md-4">
                <label className="form-label">Image</label>
                <input
                  id="bannerImageInput"
                  type="file"
                  className="form-control"
                  accept="image/*"
                  onChange={(e) => {
                    const f = e.target.files?.[0] || null;
                    setFile(f);
                    if (f) setPreview(URL.createObjectURL(f));
                    else setPreview("");
                  }}
                  disabled={submitting}
                />
              </div>
              <div className="col-12 col-md-4">
                {preview ? (
                  <div>
                    <div className="form-label">Preview</div>
                    <img
                      src={preview}
                      alt="banner preview"
                      style={{ width: "100%", height: 120, objectFit: "contain", border: "1px solid #eee", borderRadius: 6 }}
                    />
                  </div>
                ) : (
                  <div className="text-muted small">Choose an image to see preview</div>
                )}
              </div>
            </div>

            <div className="mt-3 d-flex gap-2">
              <button type="submit" className="btn btn-primary" disabled={submitting}>
                {submitting ? "Uploading…" : "Add Banner"}
              </button>
              <button type="button" className="btn btn-outline-secondary" onClick={resetAddForm} disabled={submitting}>
                Reset
              </button>
              <button type="button" className="btn btn-secondary ms-auto" onClick={fetchBanners} disabled={submitting}>
                Refresh List
              </button>
            </div>

            {submitMsg && (
              <div className={`mt-2 ${submitMsg.startsWith("✅") ? "text-success" : "text-danger"}`}>
                {submitMsg}
              </div>
            )}
          </form>
        </div>
      </div>

      {/* LIST + EDIT + DELETE */}
      {loading ? (
        <div className="p-3">Loading banners…</div>
      ) : err ? (
        <div className="alert alert-danger" role="alert">
          Failed to load banners: {err}{" "}
          <button className="btn btn-sm btn-outline-light ms-2" onClick={fetchBanners}>
            Retry
          </button>
        </div>
      ) : banners.length === 0 ? (
        <div className="m-3">
          <h2 className="h5 mb-3">Banner Images</h2>
          <div className="text-muted">No banners found.</div>
        </div>
      ) : (
        <>
          <div className="d-flex align-items-center justify-content-between my-3">
            <h2 className="h5 m-0">Banner Images</h2>
            <div className="d-flex align-items-center gap-3">
              {deleteMsg && (
                <span className={deleteMsg.startsWith("✅") ? "text-success" : "text-danger"}>
                  {deleteMsg}
                </span>
              )}
              <button className="btn btn-sm btn-secondary" onClick={fetchBanners}>
                Refresh
              </button>
            </div>
          </div>

          <div className="row g-3">
            {banners.map((banner) => {
              const created = banner.created_at ? new Date(banner.created_at).toLocaleString() : "";
              const images = Array.isArray(banner.images) ? banner.images : [];
              const isEditing = editId === banner.id;
              const isDeleting = deletingId === banner.id;

              return (
                <div key={banner.id} className="col-12">
                  <div className="card shadow-sm">
                    <div className="card-body">
                      <div className="d-flex flex-wrap justify-content-between align-items-start gap-2">
                        <div>
                          <h5 className="card-title mb-1">{banner.title || `Banner #${banner.id}`}</h5>
                          {created && <div className="small text-muted">Created: {created}</div>}
                        </div>
                        <div className="d-flex gap-2">
                          {!isEditing ? (
                            <>
                              <button className="btn btn-sm btn-outline-primary" onClick={() => startEdit(banner)} disabled={isDeleting}>
                                Edit
                              </button>
                              <button
                                className="btn btn-sm btn-outline-danger"
                                onClick={() => handleDeleteBanner(banner)}
                                disabled={isDeleting}
                              >
                                {isDeleting ? "Deleting…" : "Delete"}
                              </button>
                            </>
                          ) : (
                            <button className="btn btn-sm btn-outline-secondary" onClick={cancelEdit} disabled={isDeleting}>
                              Cancel
                            </button>
                          )}
                          <span className="badge bg-primary align-self-center">ID: {banner.id}</span>
                        </div>
                      </div>

                      {/* Gallery */}
                      {images.length ? (
                        <div className="mt-3 d-flex flex-wrap gap-2">
                          {images.map((img, idx) => (
                            <div key={`${banner.id}-${idx}`} className="border rounded p-1">
                              <img
                                src={toAbsolute(img)}
                                alt={`${banner.title || "Banner"} - ${idx + 1}`}
                                style={{ width: 200, height: 120, objectFit: "cover", display: "block", borderRadius: 6 }}
                                onError={(e) => {
                                  e.currentTarget.src =
                                    "data:image/svg+xml;charset=UTF-8," +
                                    encodeURIComponent(
                                      `<svg xmlns='http://www.w3.org/2000/svg' width='200' height='120'><rect width='100%' height='100%' fill='#f2f2f2'/><text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' fill='#888' font-family='Arial' font-size='12'>Image not available</text></svg>`
                                    );
                                }}
                              />
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="mt-3 text-muted">No images for this banner.</div>
                      )}

                      {/* Inline Edit Form */}
                      {isEditing && (
                        <form className="mt-3" onSubmit={handleUpdateBanner}>
                          <div className="row g-3 align-items-end">
                            <div className="col-12 col-md-4">
                              <label className="form-label">Title</label>
                              <input
                                type="text"
                                className="form-control"
                                value={editTitle}
                                onChange={(e) => setEditTitle(e.target.value)}
                                disabled={editSubmitting}
                              />
                            </div>
                            <div className="col-12 col-md-4">
                              <label className="form-label">Replace Image (optional)</label>
                              <input
                                type="file"
                                className="form-control"
                                accept="image/*"
                                onChange={onEditFileChange}
                                disabled={editSubmitting}
                              />
                            </div>
                            <div className="col-12 col-md-4">
                              {editPreview ? (
                                <div>
                                  <div className="form-label">New Image Preview</div>
                                  <img
                                    src={editPreview}
                                    alt="new preview"
                                    style={{ width: "100%", height: 120, objectFit: "contain", border: "1px solid #eee", borderRadius: 6 }}
                                  />
                                </div>
                              ) : (
                                <div className="text-muted small">
                                  {images[0] ? (
                                    <>Current First Image: <code>{images[0]}</code></>
                                  ) : (
                                    "No current image"
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="mt-3 d-flex gap-2">
                            <button type="submit" className="btn btn-success" disabled={editSubmitting}>
                              {editSubmitting ? "Saving…" : "Save Changes"}
                            </button>
                            <button type="button" className="btn btn-outline-secondary" onClick={cancelEdit} disabled={editSubmitting}>
                              Cancel
                            </button>
                          </div>
                          {editMsg && (
                            <div className={`mt-2 ${editMsg.startsWith("✅") ? "text-success" : "text-danger"}`}>
                              {editMsg}
                            </div>
                          )}
                        </form>
                      )}
                    </div>

                    {/* Preview strip */}
                    <div className="card-footer bg-white">
                      <div className="small text-muted">Preview</div>
                      {Array.isArray(banner.images) && banner.images.length ? (
                        <div className="mt-2 d-flex flex-wrap gap-2">
                          {banner.images.map((img, idx) => (
                            <img
                              key={`preview-${banner.id}-${idx}`}
                              src={toAbsolute(img)}
                              alt={`Preview ${idx + 1}`}
                              style={{
                                width: 120,
                                height: 70,
                                objectFit: "contain",
                                border: "1px solid #eee",
                                borderRadius: 4,
                                background: "#fff",
                              }}
                              onError={(e) => {
                                e.currentTarget.src =
                                  "data:image/svg+xml;charset=UTF-8," +
                                  encodeURIComponent(
                                    `<svg xmlns='http://www.w3.org/2000/svg' width='120' height='70'><rect width='100%' height='100%' fill='#fafafa'/><text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' fill='#aaa' font-family='Arial' font-size='10'>No preview</text></svg>`
                                  );
                              }}
                            />
                          ))}
                        </div>
                      ) : (
                        <div className="small text-muted">No preview available</div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
};

export default BannerImages;
