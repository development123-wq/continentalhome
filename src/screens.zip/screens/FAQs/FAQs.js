import React, { useState, useEffect } from "react";
import { Editor } from "@tinymce/tinymce-react";

const FaqEditor = () => {
  const [faqData, setFaqData] = useState({
    banner_image: "",
    title1: "",
    description1: "",
    title2: "",
    description2: "",
    title3: "",
    description3: "",
    title4: "",
    description4: "",
    title5: "",
    description5: "",
    title6: "",
    description6: "",
    title7: "",
    description7: "",
  });

  useEffect(() => {
    const token = sessionStorage.getItem("authToken");
    console.log("GET Token:", token);

    if (!token) {
      alert("Authorization token missing! Please login.");
      return;
    }

    fetch("http://187.124.157.146:5001/api/faq", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((res) => {
        if (!res.ok) throw new Error("Failed to fetch FAQ data");
        return res.json();
      })
      .then((data) => setFaqData(data))
      .catch((err) => {
        console.error("Fetch failed:", err);
        alert("Failed to fetch FAQ data.");
      });
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFaqData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleEditorChange = (content, editor, name) => {
    setFaqData((prev) => ({
      ...prev,
      [name]: content,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = sessionStorage.getItem("authToken");
    console.log("PUT Token:", token);

    if (!token) {
      alert("Authorization token missing! Please login.");
      return;
    }

    try {
      const response = await fetch("http://187.124.157.146:5001/api/faq/update", {
        method: "PUT", 
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(faqData),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      console.log("API Response:", result);

      if (result?.success || result?.message || result?.status === "success") {
        alert("FAQ updated successfully!");
      } else {
        alert("FAQ update failed!");
      }
    } catch (err) {
      console.error("Update failed:", err);
      alert("Something went wrong while updating the FAQ.");
    }
  };

  // === Inline Styles ===
  const containerStyle = {
    maxWidth: "800px",
    padding: "20px",
 
    border: "1px solid #ccc",
    borderRadius: "8px",
    fontFamily: "Arial, sans-serif",
  };

  const labelStyle = {
    fontWeight: "bold",
    marginBottom: "4px",
    display: "block",
    marginTop: "16px",
  };

  const inputStyle = {
    width: "100%",
    padding: "10px",
    borderRadius: "4px",
    border: "1px solid #ccc",
    marginTop: "4px",
  };

  const buttonStyle = {
    marginTop: "24px",
    padding: "12px 20px",
   
    color: "white",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
    textTransform: "uppercase",
  };

  return (
    <div style={containerStyle}>
      <h2 style={{ textAlign: "center", marginBottom: "20px" }}>Update FAQs</h2>
      <form onSubmit={handleSubmit}>
        <label style={labelStyle}>Banner Image URL</label>
        <input
          type="text"
          name="banner_image"
          value={faqData.banner_image}
          onChange={handleChange}
          style={inputStyle}
        />

        {[...Array(7)].map((_, index) => {
          const i = index + 1;
          return (
            <div key={i}>
              <label style={labelStyle}>{`Title ${i}`}</label>
              <input
                type="text"
                name={`title${i}`}
                value={faqData[`title${i}`]}
                onChange={handleChange}
                style={inputStyle}
              />

              <label style={labelStyle}>{`Description ${i}`}</label>
              <Editor
                apiKey="ewqu5ti6bsjbxirh6rptpf3m05mwek075mt56suan91l8exv"
                value={faqData[`description${i}`]}
                init={{
                  height: 200,
                  menubar: false,
                  plugins: [
                    "advlist autolink lists link image charmap preview anchor",
                    "searchreplace visualblocks code fullscreen",
                    "insertdatetime media table paste code help wordcount",
                  ],
                  toolbar:
                    "undo redo | formatselect | bold italic backcolor | " +
                    "alignleft aligncenter alignright alignjustify | " +
                    "bullist numlist outdent indent | removeformat | help",
                }}
                onEditorChange={(content, editor) =>
                  handleEditorChange(content, editor, `description${i}`)
                }
              />
            </div>
          );
        })}

        <button className="bg-blue-600 text-white px-4 py-2 rounded mt-3 btn btn-primary btn-set-task w-sm-100 text-uppercase px-5" type="submit" style={buttonStyle}>
          Save FAQ
        </button>
      </form>
    </div>
  );
};

export default FaqEditor;
