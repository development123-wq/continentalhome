import React, { useEffect } from 'react';
import {
  Route,
  Routes as ReactRoutes,
  Navigate,
  useLocation
} from "react-router-dom";

import Dashboard from './Dashboard/Dashboard';
import ProductGrid from './Products/ProductGrid';
import ProductList from './Products/ProductList';
import ProductEdit from './Products/ProductEdit';
import ProductDetail from './Products/ProductDetail';
import ProductAdd from './Products/ProductAdd';
import AboutUs from './AboutUs/AboutUs';
import TnC from './TnC/TnC';
import AllBlog from './AllBlog/AllBlog';
import Support from './Support/Support';
import Subscribers from './Subscribers/Subscribers';
import SupportDetails from './Support/SupportDetails';
import AddBlog from './AllBlog/AddBlog';
import BannerImages from './BannerImages/BannerImages';
import FeaturedImages from './FeaturedProducts/FeaturedProducts';
import EditBlog from './AllBlog/EditBlog';
import PP from './PrivacyPolicy/PrivacyPolicy';
import AdminFAQs from './FAQs/FAQs';
import ReturnnRefund from './ReturnnRefund/ReturnnRefund';
import ProductImport from './Products/ProductImport';
import ShoppingCart from './Products/ShoppingCart';
import Header from '../components/common/Header';
import CheckOut from './Products/CheckOut';
import CategoriesList from './Categories/CategoriesList';
import SubCategoriesList from './SubCategories/SubCategoriesList';
import OrderList from './Orders/OrderList';
import OrderDetail from './Orders/OrderDetail';
import OrderPDFView from './Orders/OrderPDFView';
import OrderInvoice from './Orders/OrderInvoice';
import CustomerList from './Customers/CustomerList';
import CustomerDetail from './Customers/CustomerDetail';
import CouponsList from './SalesPromotion/CouponsList';
import CouponsAdd from './SalesPromotion/CouponsAdd';
import CouponsEdit from './SalesPromotion/CouponsEdit';
import StockList from './Inventory/StockList';
import Purchase from './Inventory/Purchase';
import Supplier from './Inventory/Supplier';
import Return from './Inventory/Return';
import Departments from './Inventory/Departments';
import Invoices from './Accounts/Invoices';
import Expense from './Accounts/Expense';
import Salaryslip from './Accounts/Salaryslip';
import Chat from './App/Chat';
import ProfilePage from './Other Pages/ProfilePage';
import PricePlanExample from './Other Pages/PricePlanExample';
import ContactUs from './Other Pages/ContactUs';
import Icons from './Other Pages/Icon';
import FormsExample from './Other Pages/FormsExample';
import TableExample from './Other Pages/TableExample';
import ChartsExample from './Other Pages/ChartsExample';
import Alerts from './Uicomponent/Alerts';
import Badges from './Uicomponent/Badge';
import Breadcrumb from './Uicomponent/Breadcrumb';
import Buttons from './Uicomponent/Buttons';
import Cards from './Uicomponent/Card';
import Carousel from './Uicomponent/Carousel';
import Collapse from './Uicomponent/Collapse';
import Dropdowns from './Uicomponent/Dropdowns';
import ListGroup from './Uicomponent/ListGroup';
import ModalUI from './Uicomponent/Modal';
import NavbarUI from './Uicomponent/Navbar';
import NavsUI from './Uicomponent/Navs';
import PaginationUI from './Uicomponent/Pagination';
import PopoversUI from './Uicomponent/Popovers';
import ProgressUI from './Uicomponent/Progress';
import Scrollspy from './Uicomponent/Scrollspy';
import SpinnersUI from './Uicomponent/Spinners';
import ToastsUI from './Uicomponent/Toasts';
import Calendar from './App/Calendar';
import StaterPage from './Stater Page/StaterPage';
import Documentation from './Documentation/Documentation';
import Changelog from './Changelog/Changelog';
import CategoriesEdit from './Categories/CategoriesEdit';
import CategoriesAdd from './Categories/CategoriesAdd';
import SubCategoriesEdit from './SubCategories/SubCategoriesEdit';
import SubCategoriesAdd from './SubCategories/SubCategoriesAdd';
import CatSuccess from './Categories/CategoriesSuccess';
import StoreLocation from './StoreLocation/Storelocation';
import Help from './Help/Help';
import SimpleInvoice from '../components/Accounts/Invoice/SimpleInvoice';

// Frontend
import Home from './Frontend/Home';
import About from './Frontend/About/About';
import Shop from './Frontend/Shop/Shop';
import Blogs from './Frontend/Blogs/Blogs';
import Contact from './Frontend/Contact/Contact';
import Faqs from './Frontend/Faqs/Faqs';
import NotFound from './Frontend/NotFound';

function MainIndex(props) {
  const { activekey } = props;
  const location = useLocation();

  // 🔥 HIDE SIDEMENU & NAVBAR ON /404
  useEffect(() => {
    // mainsidemenu (id)
    const sideMenu = document.getElementById("mainsidemenu");
    if (sideMenu) {
      sideMenu.style.display =
        location.pathname === "/404" ? "none" : "block";
    }

    // navbar (class)
    const navbars = document.getElementsByClassName("navbar");
    for (let i = 0; i < navbars.length; i++) {
      navbars[i].style.display =
        location.pathname === "/404" ? "none" : "flex";
    }
  }, [location.pathname]);

  return (
    <div className="main px-lg-4 px-md-4">
      {activekey === "/chat" ? "" : <Header />}

      <div className="body d-flex py-3">
        <ReactRoutes>

          {/* Frontend */}
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/blogs" element={<Blogs />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/faqs" element={<Faqs />} />

          {/* 404 */}
          <Route path="/404" element={<NotFound />} />
          <Route path="*" element={<Navigate to="/404" replace />} />

          {/* Admin / Dashboard */}
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/product-grid" element={<ProductGrid />} />
          <Route path="/product-list" element={<ProductList />} />
          <Route path="/product-edit" element={<ProductEdit />} />
          <Route path="/product-detail" element={<ProductDetail />} />
          <Route path="/product-add" element={<ProductAdd />} />

          <Route path="/about-us" element={<AboutUs />} />
          <Route path="/privacypolicy" element={<PP />} />
          <Route path="/terms-conditions" element={<TnC />} />
          <Route path="/admin-faqs" element={<AdminFAQs />} />
          <Route path="/return-and-refund" element={<ReturnnRefund />} />

          <Route path="/all-blogs" element={<AllBlog />} />
          <Route path="/add-blog" element={<AddBlog />} />
          <Route path="/edit-blog" element={<EditBlog />} />

          <Route path="/banner-image" element={<BannerImages />} />
          <Route path="/featured-products" element={<FeaturedImages />} />

          <Route path="/support" element={<Support />} />
          <Route path="/support-details" element={<SupportDetails />} />
          <Route path="/subscribers" element={<Subscribers />} />

          <Route path="/product-import" element={<ProductImport />} />
          <Route path="/shopping-cart" element={<ShoppingCart />} />
          <Route path="/check-out" element={<CheckOut />} />

          <Route path="/categories-list" element={<CategoriesList />} />
          <Route path="/categories-edit" element={<CategoriesEdit />} />
          <Route path="/categories-add" element={<CategoriesAdd />} />
          <Route path="/categories-success" element={<CatSuccess />} />

          <Route path="/subcategories-list" element={<SubCategoriesList />} />
          <Route path="/subcategories-edit" element={<SubCategoriesEdit />} />
          <Route path="/subcategories-add" element={<SubCategoriesAdd />} />

          <Route path="/order-list" element={<OrderList />} />
          <Route path="/order-detail" element={<OrderDetail />} />
          <Route path="/pdf-view" element={<OrderPDFView />} />
          <Route path="/order-invoice" element={<OrderInvoice />} />

          <Route path="/customer-list" element={<CustomerList />} />
          <Route path="/customer-detail" element={<CustomerDetail />} />

          <Route path="/coupons-list" element={<CouponsList />} />
          <Route path="/coupons-add" element={<CouponsAdd />} />
          <Route path="/coupons-edit" element={<CouponsEdit />} />

          <Route path="/stock-list" element={<StockList />} />
          <Route path="/purchase" element={<Purchase />} />
          <Route path="/supplier" element={<Supplier />} />
          <Route path="/return" element={<Return />} />
          <Route path="/departments" element={<Departments />} />

          <Route path="/invoices" element={<Invoices />} />
          <Route path="/simple-invoice" element={<SimpleInvoice />} />
          <Route path="/expense" element={<Expense />} />
          <Route path="/salaryslip" element={<Salaryslip />} />

          <Route path="/chat" element={<Chat />} />
          <Route path="/calendar" element={<Calendar />} />
          <Route path="/store-location" element={<StoreLocation />} />

          <Route path="/profile-pages" element={<ProfilePage />} />
          <Route path="/price-plan" element={<PricePlanExample />} />
          <Route path="/contact-us" element={<ContactUs />} />
          <Route path="/icons" element={<Icons />} />
          <Route path="/form-example" element={<FormsExample />} />
          <Route path="/table-example" element={<TableExample />} />
          <Route path="/charts-example" element={<ChartsExample />} />

          <Route path="/ui-alerts" element={<Alerts />} />
          <Route path="/ui-badge" element={<Badges />} />
          <Route path="/ui-breadcrumb" element={<Breadcrumb />} />
          <Route path="/ui-buttons" element={<Buttons />} />
          <Route path="/ui-card" element={<Cards />} />
          <Route path="/ui-carousel" element={<Carousel />} />
          <Route path="/ui-collapse" element={<Collapse />} />
          <Route path="/ui-dropdowns" element={<Dropdowns />} />
          <Route path="/ui-listgroup" element={<ListGroup />} />
          <Route path="/ui-modalui" element={<ModalUI />} />
          <Route path="/ui-navbarui" element={<NavbarUI />} />
          <Route path="/ui-navsui" element={<NavsUI />} />
          <Route path="/ui-paginationui" element={<PaginationUI />} />
          <Route path="/ui-popoversui" element={<PopoversUI />} />
          <Route path="/ui-progressui" element={<ProgressUI />} />
          <Route path="/ui-scrollspyui" element={<Scrollspy />} />
          <Route path="/ui-spinnersui" element={<SpinnersUI />} />
          <Route path="/ui-toastsui" element={<ToastsUI />} />

          <Route path="/stater-page" element={<StaterPage />} />
          <Route path="/documentation" element={<Documentation />} />
          <Route path="/changelog" element={<Changelog />} />
          <Route path="/help" element={<Help />} />

        </ReactRoutes>
      </div>
    </div>
  );
}

export default MainIndex;
