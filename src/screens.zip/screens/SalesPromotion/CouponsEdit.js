import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import PageHeader1 from '../../components/common/PageHeader1';

function CouponsEdit() {
    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);
    const couponCode = queryParams.get('code');

    const [formData, setFormData] = useState({
        id: '',
        code: '',
        discount_type: '',
        discount_value: '',
        active_date: '',
        expiry_date: '',
        is_active: 1
    });

    const [message, setMessage] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (couponCode) {
            fetchCouponByCode(couponCode);
        }
    }, [couponCode]);

    const fetchCouponByCode = async (code) => {
        try {
            const response = await fetch(`http://187.124.157.146:5001/api/coupons?page=1&limit=10&search=${code}`);
            const result = await response.json();

            if (response.ok && result.coupons && result.coupons.length > 0) {
                const coupon = result.coupons[0];
                setFormData({
                    id: coupon.id,
                    code: coupon.code,
                    discount_type: coupon.discount_type,
                    discount_value: coupon.discount_value,
                    active_date: coupon.active_date?.split('T')[0] || '',
                    expiry_date: coupon.expiry_date?.split('T')[0] || '',
                    is_active: coupon.is_active
                });
            } else {
                setMessage("❌ Coupon not found.");
            }
        } catch (error) {
            console.error("Error fetching coupon:", error);
            setMessage("❌ Failed to load coupon.");
        } finally {
            setLoading(false);
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleUpdate = async (e) => {
        e.preventDefault();
        setMessage("Updating...");

        const token = sessionStorage.getItem('authToken');

        try {
            const response = await fetch(`http://187.124.157.146:5001/api/coupons/update/${formData.id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    code: formData.code,
                    discount_type: formData.discount_type,
                    discount_value: parseFloat(formData.discount_value),
                    active_date: formData.active_date,
                    expiry_date: formData.expiry_date,
                    is_active: parseInt(formData.is_active)
                })
            });

            const result = await response.json();

            if (response.ok) {
                setMessage("✅ Coupon updated successfully!");
            } else {
                setMessage("❌ Failed to update: " + (result.message || "Unknown error"));
            }
        } catch (error) {
            console.error("Update failed:", error);
            setMessage("❌ Something went wrong!");
        }
    };

    return (
        <div className="body d-flex py-lg-3 py-md-2">
            <div className="container-xxl">
                <PageHeader1 pagetitle='Coupons Edit' />
                {loading ? (
                    <div className="alert alert-info mt-4">Loading...</div>
                ) : (
                    <div className="card mt-4">
                        <div className="card-body">
                            <form onSubmit={handleUpdate}>
                                <div className="mb-3">
                                    <label className="form-label">Coupon Code</label>
                                    <input type="text" name="code" className="form-control" value={formData.code} onChange={handleChange} required />
                                </div>

                                <div className="mb-3">
                                    <label className="form-label">Discount Type</label>
                                    <select name="discount_type" className="form-control" value={formData.discount_type} onChange={handleChange}>
                                        <option value="percentage">Percentage</option>
                                        <option value="flat">Flat</option>
                                    </select>
                                </div>

                                <div className="mb-3">
                                    <label className="form-label">Discount Value</label>
                                    <input type="number" name="discount_value" className="form-control" value={formData.discount_value} onChange={handleChange} required />
                                </div>

                                <div className="mb-3">
                                    <label className="form-label">Active Date</label>
                                    <input type="date" name="active_date" className="form-control" value={formData.active_date} onChange={handleChange} required />
                                </div>

                                <div className="mb-3">
                                    <label className="form-label">Expiry Date</label>
                                    <input type="date" name="expiry_date" className="form-control" value={formData.expiry_date} onChange={handleChange} required />
                                </div>

                                <div className="mb-3">
                                    <label className="form-label">Status</label>
                                    <select name="is_active" className="form-control" value={formData.is_active} onChange={handleChange}>
                                        <option value={1}>Active</option>
                                        <option value={0}>Inactive</option>
                                    </select>
                                </div>

                                <button type="submit" className="btn btn-primary">Update Coupon</button>

                                {message && (
                                    <div className="alert alert-info mt-3">{message}</div>
                                )}
                            </form>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}

export default CouponsEdit;
