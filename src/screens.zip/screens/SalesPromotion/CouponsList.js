import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { Link } from 'react-router-dom';
import PageHeader1 from '../../components/common/PageHeader1';

function CouponsList() {
    const [table_row, setTable_row] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchCoupons();
    }, []);

    const fetchCoupons = async () => {
        try {
            const response = await fetch("http://187.124.157.146:5001/api/coupons?page=1&limit=10");
            const result = await response.json();

            if (response.ok && result.coupons) {
                setTable_row(result.coupons);
            } else {
                console.error("Data fetch error:", result);
            }
        } catch (error) {
            console.error("API fetch failed:", error);
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (id) => {
        const token = sessionStorage.getItem('authToken');

        const confirmDelete = window.confirm("Are you sure you want to delete this coupon?");
        if (!confirmDelete) return;

        try {
            const response = await fetch(`http://187.124.157.146:5001/api/coupons/delete/${id}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.ok) {
                setTable_row(prev => prev.filter((item) => item.id !== id));
                alert('Coupon deleted successfully');
            } else {
                const result = await response.json();
                alert('Failed to delete: ' + (result.message || 'Unknown error'));
            }
        } catch (error) {
            console.error("Delete failed:", error);
            alert('Something went wrong while deleting the coupon.');
        }
    };

    const columns = () => [
        {
            name: "COUPONS CODE",
            selector: (row) => row.code,
            sortable: true,
        },
        {
            name: "TYPE",
            selector: (row) => row.discount_type,
            sortable: true,
        },
        {
            name: "DISCOUNT",
            selector: (row) => `${row.discount_value}${row.discount_type === "percentage" ? "%" : ""}`,
            sortable: true,
        },
        {
            name: "START DATE",
            selector: (row) => new Date(row.active_date).toLocaleDateString(),
            sortable: false,
        },
        {
            name: "END DATE",
            selector: (row) => new Date(row.expiry_date).toLocaleDateString(),
            sortable: true,
        },
        {
            name: "STATUS",
            selector: (row) => row.is_active ? "Active" : "Inactive",
            sortable: true,
            cell: (row) => (
                <span className={`badge ${row.is_active ? 'bg-success' : 'bg-danger'}`}>
                    {row.is_active ? "Active" : "Inactive"}
                </span>
            )
        },
        
        {
            name: "ACTION",
            cell: (row) => (
                <div className="btn-group" role="group">
                    <Link to={`${process.env.PUBLIC_URL}/coupons-edit?code=${row.code}`}>
                        <button type="button" className="btn btn-outline-secondary">
                            <i className="icofont-edit text-success"></i>
                        </button>
                    </Link>
                    <button
                        type="button"
                        onClick={() => handleDelete(row.id)}
                        className="btn btn-outline-secondary deleterow"
                    >
                        <i className="icofont-ui-delete text-danger"></i>
                    </button>
                </div>
            )
        }
    ];

    return (
        <div className="body d-flex py-lg-3 py-md-2">
            <div className="container-xxl">
                <PageHeader1 pagetitle='Coupons' righttitle='Add Coupons' link='/coupons-add' routebutton={true} />
                <div className="row clearfix g-3">
                    <div className="col-sm-12">
                        <div className="card mb-3">
                            <div className="card-body">
                                <div id="myProjectTable_wrapper" className="dataTables_wrapper dt-bootstrap5 no-footer">
                                    <div className="row">
                                        <div className="col-sm-12">
                                            <DataTable
                                                columns={columns()}
                                                data={table_row}
                                                progressPending={loading}
                                                defaultSortField="code"
                                                pagination
                                                selectableRows={false}
                                                className="table myDataTable table-hover align-middle mb-0 d-row nowrap dataTable no-footer dtr-inline"
                                                highlightOnHover={true}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default CouponsList;
