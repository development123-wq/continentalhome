import React, { useState } from 'react';
import PageHeader1 from '../../components/common/PageHeader1';

function CouponsAdd() {
    const [formData, setFormData] = useState({
        code: '',
        discount_type: 'percentage',
        discount_value: '',
        expiry_date: '',
        active_date: '',
        is_active: 1
    });

    const [message, setMessage] = useState('');

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage('Submitting...');

        const token = sessionStorage.getItem('authToken');

        try {
            const response = await fetch('http://187.124.157.146:5001/api/coupons/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    ...formData,
                    discount_value: parseFloat(formData.discount_value),
                    is_active: parseInt(formData.is_active)
                })
            });

            const result = await response.json();

            if (response.ok) {
                setMessage('✅ Coupon added successfully!');
                setFormData({
                    code: '',
                    discount_type: 'percentage',
                    discount_value: '',
                    expiry_date: '',
                    active_date: '',
                    is_active: 1
                });
            } else {
                setMessage('❌ Failed to add coupon: ' + (result.message || 'Unknown error'));
            }
        } catch (error) {
            console.error('Error:', error);
            setMessage('❌ Something went wrong!');
        }
    };

    return (
        <div className="body d-flex py-lg-3 py-md-2">
            <div className="container-xxl">
                <PageHeader1 pagetitle='Add Coupon' />

                <div className="card mt-4">
                    <div className="card-body">
                        <form onSubmit={handleSubmit}>
                            <div className="mb-3">
                                <label className="form-label">Coupon Code</label>
                                <input
                                    type="text"
                                    name="code"
                                    className="form-control"
                                    value={formData.code}
                                    onChange={handleChange}
                                    required
                                />
                            </div>

                            <div className="mb-3">
                                <label className="form-label">Discount Type</label>
                                <select
                                    name="discount_type"
                                    className="form-control"
                                    value={formData.discount_type}
                                    onChange={handleChange}
                                >
                                    <option value="percentage">Percentage</option>
                                    <option value="flat">Flat</option>
                                </select>
                            </div>

                            <div className="mb-3">
                                <label className="form-label">Discount Value</label>
                                <input
                                    type="number"
                                    name="discount_value"
                                    className="form-control"
                                    value={formData.discount_value}
                                    onChange={handleChange}
                                    required
                                />
                            </div>

                            <div className="mb-3">
                                <label className="form-label">Active Date</label>
                                <input
                                    type="date"
                                    name="active_date"
                                    className="form-control"
                                    value={formData.active_date}
                                    onChange={handleChange}
                                    required
                                />
                            </div>

                            <div className="mb-3">
                                <label className="form-label">Expiry Date</label>
                                <input
                                    type="date"
                                    name="expiry_date"
                                    className="form-control"
                                    value={formData.expiry_date}
                                    onChange={handleChange}
                                    required
                                />
                            </div>

                            <div className="mb-3">
                                <label className="form-label">Status</label>
                                <select
                                    name="is_active"
                                    className="form-control"
                                    value={formData.is_active}
                                    onChange={handleChange}
                                >
                                    <option value={1}>Active</option>
                                    <option value={0}>Inactive</option>
                                </select>
                            </div>

                            <button type="submit" className="btn btn-primary">
                                Add Coupon
                            </button>

                            {message && (
                                <div className="alert alert-info mt-3">
                                    {message}
                                </div>
                            )}
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default CouponsAdd;
