import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Trash2 } from 'lucide-react';
import './featuredDashboard.css';

const FeaturedDashboard = () => {
  const [featureds, setFeatureds] = useState([]);
  const [title, setTitle] = useState('');
  const [link, setLink] = useState('');
  const [image, setImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [editId, setEditId] = useState(null);

  const token = sessionStorage.getItem('authToken');

  const fetchFeatureds = async () => {
    try {
      const res = await axios.get('http://187.124.157.146:5001/api/featureds');
      setFeatureds(res.data);
    } catch (err) {
      console.error('Error fetching data:', err);
    }
  };

  useEffect(() => {
    fetchFeatureds();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!title || !link) {
      return alert('Title and link are required');
    }

    if (!editId && !image) {
      return alert('Image is required while adding');
    }

    const formData = new FormData();
    formData.append('title', title);
    formData.append('link', link);
    if (image) formData.append('image', image);

    try {
      setLoading(true);
      if (editId) {
        console.log('Updating ID:', editId);
        await axios.put(`http://187.124.157.146:5001/api/featureds/update/${editId}`, formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: `Bearer ${token}`,
          },
        });
      } else {
        console.log('Creating new banner');
        await axios.post('http://187.124.157.146:5001/api/featureds/create', formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: `Bearer ${token}`,
          },
        });
      }

      setTitle('');
      setLink('');
      setImage(null);
      setEditId(null);
      fetchFeatureds();
    } catch (err) {
      console.error('Error in submission:', err.response || err.message);
      alert(editId ? 'Update failed' : 'Add failed');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://187.124.157.146:5001/api/featureds/delete/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchFeatureds();
    } catch (err) {
      console.error('Delete failed:', err);
      alert('Delete failed');
    }
  };

  const handleEditClick = (item) => {
    setEditId(item.id);
    setTitle(item.title);
    setLink(item.link);
    setImage(null); // Optional: user can re-upload
  };

  return (
    <div className="dashboard-container">
      <h2 className="dashboard-heading">Featured Banners</h2>

      <form onSubmit={handleSubmit} className="featured-form">
        <input
          type="text"
          placeholder="Enter Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <input
          type="text"
          placeholder="Enter Link"
          value={link}
          onChange={(e) => setLink(e.target.value)}
        />
        <input
          type="file"
          onChange={(e) => setImage(e.target.files[0])}
        />
        <button type="submit" disabled={loading}>
          {loading ? (editId ? 'Updating...' : 'Adding...') : editId ? 'Update Banner' : 'Add Featured Banner'}
        </button>
      </form>

      <div className="featured-list">
        {featureds.length === 0 ? (
          <p>No featured items found.</p>
        ) : (
          featureds.map((item) => (
            <div className="featured-card" key={item.id}>
              <img
                src={`http://187.124.157.146:5001/${item.image}`}
                alt={item.title}
              />
              <div className="featured-info">
                <h4>{item.title}</h4>
                <p>🔗 {item.link}</p>
              </div>
              <div className="action-buttons">
                <button
                  type="button"
                  className="edit-btn"
                  onClick={() => handleEditClick(item)}
                >
                  ✏️
                </button>
                <button
                  type="button"
                  className="delete-btn"
                  onClick={() => handleDelete(item.id)}
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default FeaturedDashboard;
