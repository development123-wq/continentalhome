import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './aboutus.css';
import { Editor } from '@tinymce/tinymce-react';

const AboutUs = () => {
  const [formData, setFormData] = useState({
    id: 1,
    title: '',
    description: '',
    banner_image: null,
    mission_title: '',
    mission_description: '',
    mission_image: null,
    vision_title: '',
    vision_description: '',
    vision_image: null,
  });

  const [previewBanner, setPreviewBanner] = useState(null);
  const [previewMission, setPreviewMission] = useState(null);
  const [previewVision, setPreviewVision] = useState(null);

  useEffect(() => {
    axios.get('http://187.124.157.146:5001/api/aboutus')
      .then(res => {
        const about = res.data.aboutUs;
        setFormData({
          id: about.id,
          title: about.title,
          description: about.description,
          banner_image: null,
          mission_title: about.mission_title || '',
          mission_description: about.mission_description || '',
          mission_image: null,
          vision_title: about.vision_title || '',
          vision_description: about.vision_description || '',
          vision_image: null,
        });

        if (about.banner_image) {
          setPreviewBanner(`http://187.124.157.146:5001/${about.banner_image.replace(/\\/g, '/')}`);
        }
        if (about.mission_image) {
          setPreviewMission(`http://187.124.157.146:5001/${about.mission_image.replace(/\\/g, '/')}`);
        }
        if (about.vision_image) {
          setPreviewVision(`http://187.124.157.146:5001/${about.vision_image.replace(/\\/g, '/')}`);
        }
      })
      .catch(err => console.error("Error fetching data:", err));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleEditorChange = (content, name) => {
    setFormData(prev => ({
      ...prev,
      [name]: content
    }));
  };

  const handleFileChange = (e, type) => {
    const file = e.target.files[0];
    if (file) {
      setFormData(prev => ({
        ...prev,
        [`${type}_image`]: file
      }));

      const previewURL = URL.createObjectURL(file);

      if (type === 'banner') setPreviewBanner(previewURL);
      else if (type === 'mission') setPreviewMission(previewURL);
      else if (type === 'vision') setPreviewVision(previewURL);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = new FormData();
    data.append('id', formData.id);
    data.append('title', formData.title);
    data.append('description', formData.description);
    data.append('mission_title', formData.mission_title);
    data.append('mission_description', formData.mission_description);
    data.append('vision_title', formData.vision_title);
    data.append('vision_description', formData.vision_description);

    if (formData.banner_image) data.append('banner_image', formData.banner_image);
    if (formData.mission_image) data.append('mission_image', formData.mission_image);
    if (formData.vision_image) data.append('vision_image', formData.vision_image);

    try {
      
      const token =
       localStorage.getItem('authToken')||
       sessionStorage.getItem('authToken');

      console.log("Token:", token);

      if (!token) {
        alert("Session expired. Please login again.");
        return;
      }

      await axios.put(
        'http://187.124.157.146:5001/api/aboutus/update/1',
        data,
        {
          headers: {
            
            Authorization: `Bearer ${token}`
          }
        }
      );

      alert('Data updated successfully!');
    } catch (error) {
      console.error("Error updating data:", error.response?.data || error.message);
      alert(error.response?.data?.message || 'Invalid or expired token');
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto aboutus">
      <h2 className="text-xl font-bold mb-4">Update About Us</h2>
      <form onSubmit={handleSubmit} encType="multipart/form-data">
        <div className="mb-3">
          <label className="block mb-1">Title</label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            className="border p-2 w-full"
            required
          />
        </div>

        <div className="mb-3">
          <label className="block mb-1">Description</label>
          <Editor
            apiKey="ewqu5ti6bsjbxirh6rptpf3m05mwek075mt56suan91l8exv"
            value={formData.description}
            onEditorChange={(content) => handleEditorChange(content, 'description')}
            init={{
              height: 400,
              menubar: true,
              plugins: 'lists link image code table media',
              toolbar: 'undo redo | formatselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | image media table | code',
            }}
          />
        </div>

        <div className="mb-3">
          <label className="block mb-1">About Image</label>
          <input type="file" accept="image/*" onChange={(e) => handleFileChange(e, 'banner')} />
          {previewBanner && <img src={previewBanner} alt="Preview" className="h-32 mt-2 object-cover rounded" />}
        </div><br /><br />

        <div className="mb-3">
          <label className="block mb-1">Mission Title</label>
          <input
            type="text"
            name="mission_title"
            value={formData.mission_title}
            onChange={handleChange}
            className="border p-2 w-full"
            disabled
          />
        </div>

        <div className="mb-3">
          <label className="block mb-1">Mission Description</label>
          <Editor
            apiKey="ewqu5ti6bsjbxirh6rptpf3m05mwek075mt56suan91l8exv"
            value={formData.mission_description}
            onEditorChange={(content) => handleEditorChange(content, 'mission_description')}
            init={{
              height: 400,
              menubar: true,
              plugins: 'lists link image code table media',
              toolbar: 'undo redo | formatselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | image media table | code',
            }}
          />
        </div>

        <div className="mb-3">
          <label className="block mb-1">Mission Image</label>
          <input type="file" accept="image/*" onChange={(e) => handleFileChange(e, 'mission')} />
          {previewMission && <img src={previewMission} alt="Preview" className="h-32 mt-2 object-cover rounded" />}
        </div><br /><br />

        <div className="mb-3">
          <label className="block mb-1">Vision Title</label>
          <input
            type="text"
            name="vision_title"
            value={formData.vision_title}
            onChange={handleChange}
            className="border p-2 w-full"
            disabled
          />
        </div>

        <div className="mb-3">
          <label className="block mb-1">Vision Description</label>
          <Editor
            apiKey="ewqu5ti6bsjbxirh6rptpf3m05mwek075mt56suan91l8exv"
            value={formData.vision_description}
            onEditorChange={(content) => handleEditorChange(content, 'vision_description')}
            init={{
              height: 400,
              menubar: true,
              plugins: 'lists link image code table media',
              toolbar: 'undo redo | formatselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | image media table | code',
            }}
          />
        </div>

        <div className="mb-3">
          <label className="block mb-1">Vision Image</label>
          <input type="file" accept="image/*" onChange={(e) => handleFileChange(e, 'vision')} />
          {previewVision && <img src={previewVision} alt="Preview" className="h-32 mt-2 object-cover rounded" />}
        </div>

        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded mt-3 btn btn-primary btn-set-task w-sm-100 text-uppercase px-5">
          Update
        </button>
      </form>
    </div>
  );
};

export default AboutUs;
