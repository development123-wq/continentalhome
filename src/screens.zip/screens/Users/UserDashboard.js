import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Navbar from '../Frontend/Navbar/Navbar';
import Footer from '../Frontend/Footer/Footer';
import InnerBanner from '../Frontend/InnerBanner/InnerBanner';
import b1 from '../../assets/images/banner/category-banner-back.jpg';

import Dashboard from '../../components/Users/Dashboard';
import Orders from '../../components/Users/Orders';
import OrderDetails from '../../components/Users/OrderDetails';
import Returns from '../../components/Users/Returns';
import Messages from '../../components/Users/Messages';
import Addresses from '../../components/Users/Addresses';
import WishLists from '../../components/Users/Wishlists';
import AccountSettings from '../../components/Users/AccountSettings';

const Checkout = () => {
  const [activeStep, setActiveStep] = useState(1);
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const navigate = useNavigate();

  
  useEffect(() => {
    const token = sessionStorage.getItem('authToken');
    if (!token) {
      navigate('/sign-in');
      window.location.reload();
    }
  }, [navigate]);

  const steps = [
    'Dashboard',
    'Orders',
    'Messages',
    'Addresses',
    'Wish Lists',
    'Account Settings',
    'Logout',
  ];

  const handleLogout = async () => {
    const token = sessionStorage.getItem('authToken');
    try {
      if (token) {
        await axios.post(
          'http://187.124.157.146:5001/api/customers/logoutcustomer',
          {},
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
      }
    } catch (error) {
      console.error('Logout failed:', error);
      alert('Logout failed. Please try again.');
    } finally {
      sessionStorage.removeItem('authToken');
      sessionStorage.removeItem('authCustomer');
      navigate('/sign-in');
    }
  };

  const renderSteps = () => (
    <div style={{ width: '250px', padding: '20px', borderRight: '1px solid #ddd' }}>
      {steps.map((step, i) => {
        const stepNum = i + 1 > 2 ? i + 2 : i + 1;
        const isActive = stepNum === activeStep;

        return (
          <div
            key={i}
            onClick={() => {
              if (step === 'Logout') {
                const confirmed = window.confirm('Are you sure you want to logout?');
                if (confirmed) {
                  handleLogout();
                }
              } else {
                setActiveStep(stepNum);
              }
            }}
            style={{
              cursor: 'pointer',
              padding: '10px 15px',
              marginBottom: '10px',
              borderRadius: '4px',
              backgroundColor: isActive ? '#63a682' : '#f0f0f0',
              color: isActive ? 'white' : '#333',
              fontWeight: isActive ? 'bold' : 'normal',
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              userSelect: 'none',
            }}
          >
            <div
              style={{
                width: '24px',
                height: '24px',
                borderRadius: '50%',
                backgroundColor: isActive ? 'white' : '#63a682',
                color: isActive ? '#63a682' : 'white',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                fontWeight: 'bold',
                fontSize: '18px',
              }}
            >
              →
            </div>
            {step}
          </div>
        );
      })}
    </div>
  );

  const renderStepContent = () => {
    switch (activeStep) {
      case 1:
        return <Dashboard />;
      case 2:
        return (
          <Orders
            onSelectOrder={(id) => {
              setSelectedOrderId(id);
              setActiveStep(99);
            }}
          />
        );
        case 3:
        return ;
      case 4:
        return <Messages />;
      case 5:
        return <Addresses />;
      case 6:
        return <WishLists />;
      case 7:
        return <AccountSettings />;
      case 99:
        return <OrderDetails orderId={selectedOrderId} />;
      default:
        return null;
    }
  };

  return (
    <div className="main-add-to-cart">
      <Navbar />
      <InnerBanner title="Account Section" backgroundImage={b1} />

      <div style={{ display: 'flex', maxWidth: '1200px', margin: '30px auto', gap: '20px' }}>
        {renderSteps()}
        <div
          style={{
            flex: 1,
            padding: '20px',
            border: '1px solid #ddd',
            borderRadius: '8px',
            backgroundColor: '#fafafa',
          }}
        >
          {renderStepContent()}
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Checkout;
