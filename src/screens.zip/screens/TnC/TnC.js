import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Editor } from '@tinymce/tinymce-react';
import './aboutus.css';

const TnC = () => {
  const [formData, setFormData] = useState({
    id: '',
    title: '',
    description: '',
  });

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get('http://187.124.157.146:5001/api/policies/terms-conditions')
      .then(res => {
        const data = res.data;
        setFormData({
          id: data.id,
          title: data.title || '',
          description: data.description || '',
        });
        setLoading(false);
      })
      .catch(err => {
        console.error("Error fetching T&C data:", err);
        setLoading(false);
      });
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleEditorChange = (content) => {
    setFormData(prev => ({
      ...prev,
      description: content
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const token = sessionStorage.getItem('authToken'); // store token here
      const response = await axios.put(
        `http://187.124.157.146:5001/api/policies/terms-conditions/${formData.id}`,
        {
          title: formData.title,
          description: formData.description
        },
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );

      alert('Terms and Conditions updated successfully!');
    } catch (error) {
      console.error("Error updating data:", error.response?.data || error.message);
      alert('Error updating Terms and Conditions');
    }
  };

  return (
    <div className="p-4 max-w-4xl mx-auto aboutus">
      <h2 className="text-2xl font-bold mb-4">Update Terms and Conditions</h2>

      {loading ? (
        <p>Loading...</p>
      ) : (
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block font-semibold mb-1">Title</label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              className="border p-2 w-full rounded"
              required
            />
          </div>

          <div className="mb-4">
            <label className="block font-semibold mb-1">Description</label>
            <Editor
              apiKey="ewqu5ti6bsjbxirh6rptpf3m05mwek075mt56suan91l8exv"
              value={formData.description}
              onEditorChange={handleEditorChange}
              init={{
                height: 400,
                menubar: false,
                plugins: [
                  'advlist autolink lists link image charmap preview anchor',
                  'searchreplace visualblocks code fullscreen',
                  'insertdatetime media table paste code help wordcount'
                ],
                toolbar:
                  'undo redo | formatselect | bold italic backcolor | ' +
                  'alignleft aligncenter alignright alignjustify | ' +
                  'bullist numlist outdent indent | removeformat | help'
              }}
            />
          </div>

          <button
            type="submit"
            className="bg-blue-600 text-white px-4 py-2 rounded mt-3 btn btn-primary btn-set-task w-sm-100 text-uppercase px-5">
            Update
          </button>
        </form>
      )}
    </div>
  );
};

export default TnC;
