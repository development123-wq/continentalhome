import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Tab, Nav, Row, Col } from 'react-bootstrap';
import ShoppingStatuschart from '../../components/dashboard/ShoppingStatuschart';
import TopShellingProductChart from '../../components/dashboard/TopShellingProductChart';
import AvgexpenceChart from '../../components/dashboard/AvgexpenceChart';
import BranchLocation from '../../components/dashboard/BranchLocation';
import ActiveUsersStatus from '../../components/dashboard/ActiveUsersStatus';
import RecentTransaction from '../../components/dashboard/RecentTransaction';
import SalesStatus from '../../components/dashboard/SalesStatus';

function Dashboard() {
  const [dashboardData, setDashboardData] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = sessionStorage.getItem('authToken');
        const response = await axios.get(
          'http://187.124.157.146:5001/api/stats/counts',
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setDashboardData(response.data.counts);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      }
    };

    fetchData();
  }, []);

  if (!dashboardData) {
    return <div className="text-center py-5">Loading dashboard...</div>;
  }

  const iconMap = {
    blogs: 'icofont-file-alt',
    categories: 'icofont-tags',
    coupons: 'icofont-ticket',
    customers: 'icofont-users-alt-4',
    orders: 'icofont-cart-alt',
    products: 'icofont-box',
    subcategories: 'icofont-listine-dots',
    order_subtotal_sum: 'icofont-money',
  };

  const renderTabContent = (tabKey) => (
    <Tab.Pane
      eventKey={tabKey}
      className="tab-pane fade show"
      id={`summery-${tabKey}`}
    >
      <div className="row g-1 g-sm-3 mb-3 row-deck">
        {Object.entries(dashboardData).map(([key, value]) => (
          <div
            key={`${tabKey}-${key}`}
            className="col-xl-4 col-lg-4 col-md-4 col-sm-6"
          >
            <div className="card">
              <div
                style={{
                  border: '1px solid #63a682',
                  borderRadius: '10px',
                }}
                className="card-body py-xl-4 py-3 d-flex flex-wrap align-items-center justify-content-between"
              >
                <div className="left-info">
                  <span className="text-muted text-capitalize">
                    {key.replace(/_/g, ' ')}
                  </span>
                  <div>
                    <span className="fs-6 fw-bold me-2">
                      {key === 'order_subtotal_sum' ? `$${value}` : value}
                    </span>
                  </div>
                </div>
                <div className="right-icon">
                  <i className={iconMap[key] || 'icofont-chart-growth'}></i>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="row g-3 mb-3">
        <div className="col-xl-12">{/* <SalesStatus /> */}</div>
      </div>

      <div className="row g-3 mb-3">
        <div className="col-xxl-8 col-xl-8">
          {/* <ShoppingStatuschart /> */}
          {/* <TopShellingProductChart /> */}
        </div>
        {/* <div className='col-xxl-4 col-xl-4'>
            <BranchLocation />
          </div> */}
      </div>

      <div className="row g-3 mb-3">
        <div className="col-lg-4 col-md-12" style={{ display: 'none' }}>
          <ActiveUsersStatus />
        </div>
        <div className="col-lg-12 col-md-12">
          <AvgexpenceChart />
        </div>
      </div>

      <div className="row g-3 mb-3">
        <div className="col-md-12">
          <RecentTransaction />
        </div>
      </div>
    </Tab.Pane>
  );

  return (
    <div className="body d-flex py-3">
      <div className="container-xxl">
        <div className="mt-1">
          <Tab.Container
            id="left-tabs-example"
            defaultActiveKey="first"
            className="col-lg-12 col-md-12"
          >
            <Row>
              {/* Tabs can be enabled here if needed */}
              <Col sm={12}>
                <Tab.Content className="tab-content mt-1">
                  {renderTabContent('first')}
                  {renderTabContent('second')}
                  {renderTabContent('third')}
                  {renderTabContent('fourth')}
                </Tab.Content>
              </Col>
            </Row>
          </Tab.Container>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
